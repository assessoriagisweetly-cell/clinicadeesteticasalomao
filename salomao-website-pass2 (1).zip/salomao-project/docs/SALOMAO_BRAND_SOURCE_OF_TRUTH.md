# SALOMÃO — BRAND SOURCE-OF-TRUTH REPORT
Research pass date: 2026-09-14/15 (updated after real Instagram recording, @esteticasalomao)
Compiled per verified-research protocol. No invented facts. Gaps marked UNKNOWN.

---

## F-UPDATED. INSTAGRAM RESEARCH (real @esteticasalomao recording reviewed)

The second uploaded video (78s) is a genuine screen recording of instagram.com/esteticasalomao/. This supersedes the earlier "F. Instagram Status" note below — that section is kept for history but is no longer the current status.

### Profile stats (observed in supplied capture, dated ~Sept 2026)
- **Handle:** @esteticasalomao
- **Display name:** Estética Salomão
- **Posts:** 3,223
- **Followers:** 43K
- **Following:** 7,313
- **Bio (verbatim, OFFICIAL BRAND CLAIM):**
  "✨Rejuvenesça. Sem promessas, só resultados.
  +15K clientes. Dados falam. A escolha é clara.
  📍Líder em Fios. Av. Paulista.
  🗣️Agende. Não adie"
- **Address shown in bio:** Av. Paulista, 2006 CJ 309, São Paulo, Brazil 01310-926
- **WhatsApp link in bio:** wa.me/5511922221327 (pre-filled text starts "Quero informações...")
- **Highlights:** Cursos · Depoimentos · Resultados

### ⚠️ SOURCE CONFLICT DETECTED
| Field | Official website | Instagram bio |
|---|---|---|
| Suite/room number | Cj. 306 | CJ 309 |
| CEP | 01310-200 | 01310-926 |
| Client-count claim | "+199 CLIENTES" | "+15K clientes" |
| WhatsApp number | not printed on homepage HTML | 5511922221327 (differs from the +55 11 99934-9773 number given in your brief/Doc 1) |

**RESOLVED (2026-09-15):** User has confirmed Instagram is the source of truth for these fields. The website build will use:
- Suite: **Cj. 309**
- CEP: **01310-926**
- Client count: **+15K clientes**
- WhatsApp: **5511922221327**

Website homepage content (Cj. 306, 01310-200, +199 clientes, +55 11 99934-9773) is now known to be stale and should NOT be used in the new build.

### Real visual/brand assets confirmed
- **Logo:** circular badge, warm orange-to-red gradient background, black script wordmark "Salomão," small caps "CLÍNICA ESTÉTICA" beneath — used as profile photo
- **Alternate/dark wordmark:** gold script "Salomão" over "CLÍNICA DE ESTÉTICA" in gold small caps, on black background — appears in a polished editorial post ("resultados em estética — Nem tudo que promete rápido entrega com segurança.")
- **Real interior photo:** a treatment room with an **orange accent wall** — genuine physical-space color evidence (distinct from Document 1's invented palette)
- **Real branded product:** a copper/metallic gift tote bag with full logo lockup
- **Real editorial-style graphic:** dark background, serif gold headline "O fio ideal não é escolhido apenas pelo nome," thread-type diagram — closer to the premium/editorial tone your brief wants than the current live website is

### Verified people (real names, appear repeatedly — treat as MEDIUM-HIGH confidence, sourced only from Instagram, no independent bios found)
- **Dra. Ana Paula Dantas** — appears to be the primary recurring presenter/founder-level figure (talking-head videos, course branding "Arquitetura da Beleza" carries her name, tagged in stories)
- **Dra. Isana Azevedo** — branded "Rainha dos Lábios" (lip-filler specialty positioning), co-presenter on course promos
- **Dra. Márcia Romão** — anatomy-focused co-presenter, PDO thread course
- **Paula Dominguez** — co-host of an Instagram Live event Aug 26
- Additional tagged/partner accounts from a story: @vida_bela_miabel, @draanapaulaadantas, @drarainhadoslabios, @drpetrizzo.aesthetics — **not independently verified as clinic staff vs. external collaborators; likely a mix of clinic team and partner/guest professionals**

**Still UNKNOWN:** exact job titles/CRM registration numbers, which of these are Salomão employees vs. visiting/partner professionals for specific courses.

### Verified courses/education (real, confirmed — corrects earlier "UNKNOWN" status in Section J)
- **"Arquitetura da Beleza"** — a course/book series associated with Dra. Ana Paula Dantas; at least a "Tratado III — Fios Absorvíveis" volume shown as a product/book cover
- **Live event:** "Do Planejamento ao Resultado" — Instagram Live, Wed Aug 26, 20h, featuring Dra. Ana Paula Dantas, Dra. Isana Azevedo, Paula Dominguez
- **In-person course:** "Domine os Fios PDO — Da Análise Anatômica à Execução Clínica — Harmonização de Glúteo e Face" — Sept 12, 2026, 8h30–18h30, at Av. Paulista, 2006, 3º andar, São Paulo (the clinic's own address) — with Dra. Márcia Romão, Dra. Ana Paula Dantas, Dra. Isana Azevedo
- **Separate partner workshop:** "PRODEEP FIOS & FINAHFIL" — Aug 13, 9h–12h, at R. Bento de Andrade, 345, Jardim Paulista — a **different address**, likely a partner venue, not the clinic itself
- **International appearance:** "Alur Medical em Seoul" — conference/brand presence in Seoul, South Korea, tagged #EUVOU — this is a partner brand (Alur Medical) event, not a Salomão-hosted course

### Content archetype observed (qualitative, per protocol — no fabricated percentages)
- **HIGH:** talking-head educational clips (recurring presenter explaining procedures, myths, a "Série Fios de PDO" multi-day content series)
- **HIGH:** real procedure/treatment close-ups (thread lifting, filler injection, PDO application)
- **MEDIUM:** before/after result pairs (matches the CASO-0XX filenames seen on the website)
- **MEDIUM:** course/event promotional graphics (dark background, gold serif type — a more premium visual register than the live site)
- **LOW-MEDIUM:** real customer comments visible in-feed (e.g., "Vcs são top demais já fiz com vcs" — @karla_lindadeviver_sp; "Clínica Ecelente amei o resultado obrigado doutora" — @luciana568362) — genuine public engagement, usable as authentic social proof if you want to cite real (public, already-published) comments
- **LOW:** lifestyle/travel content (Seoul trip, team photos from events)

### Design-principle takeaway for the website (not asset copying — per your Section 04 rule)
The Instagram content itself splits into two visual registers: (1) raw, high-frequency clinical/talking-head content (authentic but not "editorial"), and (2) a smaller set of polished graphic posts (dark background, gold serif headlines, restrained layout) that already point toward the premium editorial direction your brief wants. The website redesign should draw its *tone* from register (2), while register (1) content (real procedure clips, real talking-head video) can populate Results/Stories/Team sections as authentic substance beneath the elevated design frame.

---

## A. VERIFIED FACTS (Level 1 — official website, `esteticasalomao.com.br`)

| Fact | Value | Source | Confidence |
|---|---|---|---|
| Business name (site title) | Estética Salomão | official site `<title>` | HIGH |
| Full name used in-page | Clínica de Estética Salomão | official site footer/body | HIGH |
| Positioning tagline | "Líder em Fios de PDO em São Paulo" | official site H1 + meta description | HIGH (OFFICIAL BRAND CLAIM, not independently verified) |
| Address | Av. Paulista, 2006 – 3º Andar, Cj. 306, Cerqueira César, São Paulo – SP, 01310-200 | official site footer | HIGH |
| Instagram | instagram.com/esteticasalomao (handle confirmed by user) | official site header/footer link + user | HIGH (link exists; content not crawlable — see Section F) |
| Facebook | facebook.com/estetica.salomao | official site footer link | HIGH |
| YouTube | youtube.com/esteticasalomao | official site footer link | HIGH |
| WhatsApp/contact CTA | routes to `/aguarde-site` (placeholder booking page) | official site | HIGH — **note:** no direct wa.me link or visible phone number found in fetched HTML |
| Nav sections | RESULTADOS · DÚVIDAS · SOBRE · LOCALIZAÇÃO | official site nav | HIGH |
| Core slogan | "SEM PROMESSAS. SÓ RESULTADOS!" | official site hero | HIGH |
| Brand age claim | "Há 5 Anos Transformamos Autoestimas!" | official site "sobre" copy | HIGH (OFFICIAL BRAND CLAIM) |
| Client count claim | "+199 CLIENTES" | official site stats section | HIGH (OFFICIAL BRAND CLAIM, snapshot as of crawl date) |
| Symbol | ⚜️ (fleur-de-lis emoji) used after each treatment name | official site treatment list | HIGH |
| Service categories (6, verified) | Fios de Sustentação · Toxina Botulínica · Preenchimento (AH) · Tratamentos Íntimos · Harmonização Facial · Harmonização Corp. | official site services grid | HIGH — matches your brief's list exactly |
| Featured procedure content | Fios de PDO (Liso / com Garras) explained in detail — collagen stimulation + lifting effect | official site body copy | HIGH |
| Testimonials (short, named first-name only) | Jocilene, Renilde, Sandra, Maria, Fatima, Cecilda — ticker quotes | official site hero ticker | HIGH (OFFICIAL, but no last names/dates — treat as marketing ticker, not full case studies) |
| Named professional | "Dra Beatriz" mentioned inside one testimonial | official site testimonial ticker | MEDIUM — only source is a customer quote, not a team page; **no team page was found in the crawled homepage** |
| Result images | 37 "CASO-0XX" result photos referenced (case-numbered) | official site image URLs | HIGH — filenames exist; I have not visually inspected each for before/after content type |
| Location description | "Localizada no coração pulsante de São Paulo, na icônica Avenida Paulista" | official site body | HIGH |
| Site builder/agency | Feito por Fábio Tavares Marketing Digital | official site footer credit | HIGH |
| Last content update | article:modified_time 2025-12-15 | site meta | HIGH |
| Logo asset | `SALOMAO-LOGO-ROI-50.webp`, hosted on official CDN | official site header/footer | HIGH (asset exists; I could not download/inspect pixel-level color values — image fetch tool blocked binary retrieval) |

---

## B. OFFICIAL BRAND CLAIMS (unverified positioning language — usable as brand voice, NOT as independently-verified superlatives)

- "LÍDER EM FIOS DE PDO EM SÃO PAULO"
- "SEM PROMESSAS. SÓ RESULTADOS!"
- "Há 5 Anos Transformamos Autoestimas!"
- "+199 CLIENTES"
- "amplamente reconhecida em todo o país" (meta description)

Per protocol, these can appear as the clinic's own stated positioning but must not be rewritten as Claude-verified rankings/facts (e.g., do not say "São Paulo's #1 clinic" as objective fact).

---

## C. CUSTOMER / REVIEW INSIGHTS

**UNKNOWN.** No Google Business profile data, no Reclame Aqui profile, and no independent review aggregator entry could be found for the exact business "Clínica de Estética Salomão" / CNPJ 41.325.545/0001-55 in this research pass. Searches for Reclame Aqui returned only *other, unrelated* aesthetic clinics with similar generic names (Reviv, Zoe, Clinic Estética Avançada, etc.) — none of these belong to Salomão and none were used. The Google Maps share-link on the official site (`share.google/rKl0jWtqvSVup1302`) could not be crawled (robots-disallowed).

**Action needed from you/clinic:** direct Google Business URL, or a screenshot/export of ratings, would let me complete this section honestly.

---

## D. CURRENT VISUAL DNA (from official site only — Instagram not accessible, see F)

- Photography mix: professional/clinical stock photography (injector close-ups, skincare, "professional cosmetologist" stock imagery) **combined with** real numbered case-result photos (`CASO-001` through `CASO-037`)
- ⚜️ fleur-de-lis symbol used consistently as a small treatment-list marker — matches your brief's Section 03 DNA list
- No visible color hex values could be extracted (image binary fetch unavailable in this environment) — cannot confirm official gold/cream palette pixel values. Treat brief's Section 09 palette as NEW DESIGN-SYSTEM interpretation, not verified original brand colors, exactly as Document 1 already instructs.
- Layout style of the *current* live site is a conventional long-scroll WordPress/Elementor template (ticker testimonials, image grid, embedded Google Map) — this is useful as a baseline of "what NOT to repeat," consistent with your Section 51/60 rules against generic template structure.

---

## E. CURRENT VERBAL DNA

Recurring vocabulary confirmed on official site: **resultados, autoestima, cuidado, carinho, profissionalismo, segurança, bem-estar, sutileza, rejuvenescimento** (all appear in body copy) — this matches the vocabulary map your brief predicted almost exactly.

---

## F. INSTAGRAM STATUS — IMPORTANT CORRECTION

The uploaded video is **not** a recording of the Salomão Instagram. It is a Cosmos.so screen recording of unrelated design inspiration (a fictional "MyHealthPrac" health-tech site), saved to a Cosmos collection named "CLÍNICA DE..." — almost certainly your own moodboard for this project, not brand evidence.

You confirmed the real handle is **@esteticasalomao**. Instagram blocks automated fetching for all bots (robots.txt), and it isn't reliably indexed by search, so I could not extract bio text, follower count, highlights, or post history. This section of the protocol (Doc 2, Sections 6–7) is **UNKNOWN pending manual input** — I'd need actual screenshots or a new screen recording of the real Instagram profile to complete it.

---

## G. VERIFIED PEOPLE

UNKNOWN / NOT FOUND. Only one name surfaced ("Dra Beatriz," inside a customer testimonial quote) — not confirmable as current staff, role, or credentials from a dedicated team page. No team/equipe page was reachable from the crawled homepage. **Do not use any staff names in the website build until confirmed.**

---

## H. VERIFIED SERVICES

Confirmed current (matches your brief exactly, no changes needed):
Fios de Sustentação · Toxina Botulínica · Preenchimento (AH) · Tratamentos Íntimos · Harmonização Facial · Harmonização Corporal

---

## I. VERIFIED PRODUCTS

UNKNOWN. No product catalog/e-commerce found on the official site.

---

## J. VERIFIED COURSES

UNKNOWN. No course/academy page was found in the crawled homepage content. Your brief assumes an existing course identity (Section 31) — this needs a specific URL or confirmation, since the homepage alone doesn't show it.

---

## K. COLOR OBSERVATIONS

UNKNOWN at hex level (binary image inspection unavailable in this session). No official brand guide found. **Recommendation:** treat Document 1's Section 09 palette exactly as it's already labeled — a new design-system interpretation, not a claim about official historical colors.

---

## L. TYPOGRAPHY OBSERVATIONS

UNKNOWN — could not inspect rendered fonts (CSS not parsed at this level of fetch). No font names should be invented; describe qualitatively only, per Document 1 Section 21 and Document 2 Section 21 guidance ("high-contrast editorial serif" rather than a guessed font name), once real typography is inspected visually.

---

## M. SOURCE CONFLICTS

None detected between official site and user-provided address/phone/CNPJ — the address on the live site matches what you supplied verbatim (Av. Paulista, 2006, 3º andar, Cj. 306). No conflicting values found elsewhere because no secondary source could be confirmed as the same business.

**One gap, not a conflict:** the official site's CTAs all route to a placeholder `/aguarde-site` page rather than a live WhatsApp deep link — I did not find the phone number `+55 11 99934-9773` printed anywhere in the fetched homepage HTML. It's presumably used in the actual wa.me links behind that placeholder page, but I can't confirm it from the site itself. I'll treat the number you and Document 1 supplied as USER-PROVIDED / HIGH confidence, just noting it wasn't independently re-confirmed on-page.

---

## N. UNKNOWN / MISSING INFORMATION (updated)

**Resolved by the real Instagram recording:**
- ~~Instagram bio, followers, highlights~~ → CONFIRMED (see Section F-UPDATED)
- ~~Team/staff names~~ → PARTIALLY CONFIRMED: Dra. Ana Paula Dantas, Dra. Isana Azevedo, Dra. Márcia Romão (roles/CRM numbers still unknown; employee vs. partner status still unclear for some)
- ~~Course/Academy details~~ → CONFIRMED: "Arquitetura da Beleza" course brand, specific course/event dates and named presenters found

**Still open:**
- Google Business rating/review count — no profile located
- Reclame Aqui profile — none found for this exact business
- CNPJ registry confirmation for 41.325.545/0001-55 — not located in open CNPJ databases searched
- Product catalog beyond course materials — none found
- Verified hex colors at pixel level / exact font names — not extractable in this environment (though real photographic evidence of an orange accent wall and the gold-on-black wordmark now exists — see Section F-UPDATED)
- Whether the 37 "CASO" images on the website are genuine before/afters or a mix with stock — filenames only, not visually audited image-by-image yet
- Exact roles/CRM registration numbers for named doctors
- Which tagged Instagram accounts are Salomão employees vs. independent partner professionals

**New conflict requiring your input before build:** suite number (Cj. 306 vs CJ 309), CEP, client-count claim (+199 vs +15K), and WhatsApp number (+55 11 99934-9773 vs wa.me/5511922221327) — see Section F-UPDATED conflict table.

## O. ASSET MANIFEST (what's confirmed to exist, not yet downloaded)

| Asset | URL | Type | Confidence |
|---|---|---|---|
| Logo | esteticasalomao.com.br/wp-content/uploads/2024/05/SALOMAO-LOGO-ROI-50.webp | official | HIGH (exists, not pixel-inspected) |
| OG/thumb image | .../2025/11/THUMB.webp | official | HIGH |
| 37 case-result photos | .../2025/09/CASO-00X..., .../2025/12/CASO-0XX... | official, real result content per site framing | HIGH filename source / MEDIUM content classification (not individually audited) |
| 6 treatment stock/detail photos | various .../2025/08/ and 2024/06/ filenames | official, appear to be stock photography | MEDIUM — several filenames (e.g. "beautiful-caucasian-woman-touche.webp," "professional-cosmetologist-injec.webp") read as generic stock naming conventions, not real-patient filenames |
| 6 procedure video thumbnails | .../2025/12/video-01.webp through video-06.webp | official | HIGH (thumbnails exist; video content itself not verified) |

## P. SOURCES

- https://www.esteticasalomao.com.br/ (fetched in full, 2026-09-15)
- User-supplied: Document 1 (Master Build Prompt), Document 2 (Research Protocol), video file (identified as Cosmos.so reference reel, not Instagram), and the Instagram handle @esteticasalomao (user-provided)
- web_search_fast queries: Google Maps/reviews, Instagram handle, Reclame Aqui, CNPJ registry (all returned no matching results for this exact business)
- image_search: "esteticasalomao clinica logo" (confirmed official site is indexed; no other Salomão-specific visual assets surfaced)

---

## STOP-CONDITION CHECK (per Document 2 §39)

- [x] Official website inspected
- [ ] Supplied Instagram inspected — **NOT done, source wasn't actually Instagram; awaiting real material**
- [ ] Google Business / reviews verified — **not found**
- [ ] Reclame Aqui checked — **checked, no matching profile**
- [x] Service categories verified — matches brief exactly
- [x] Logo sourced (URL confirmed, not pixel-inspected)
- [~] Available official images catalogued — catalogued by filename, not individually content-audited
- [x] Current brand language catalogued
- [ ] Current visual colors documented — **not extractable in this environment**
- [x] Conflicts flagged (none found)
- [x] Unknowns documented (Section N)

**Per your own Document 2, Section 39, this stop condition is not fully met.** I can proceed to design/build using only what's verified (services, address, slogans, testimonial ticker quotes, ⚜️ symbol, general visual DNA), while clearly placeholder-labeling anything under "UNKNOWN" — team members, course content, products, exact colors/fonts, and review data. That's consistent with your Section 59 "Demo Content" rule: real info used as-is, unknowns omitted or clearly labeled, nothing fabricated.
