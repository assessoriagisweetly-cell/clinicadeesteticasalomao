import React from "react";
import ReactDOM from "react-dom/client";
import SalomaoSite from "./SalomaoSite.jsx";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <SalomaoSite />
  </React.StrictMode>
);
