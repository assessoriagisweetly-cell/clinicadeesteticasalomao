import { useEffect, useState, useRef, createContext, useContext } from "react";

/* ============================================================
   SALOMÃO — Full Route Skeleton (Pass 2) + Audit Fixes (Pass 3)
   Real client-side routing (hand-rolled, since react-router isn't
   available in this environment), real data models, every nav
   item / CTA / phone / WhatsApp action wired to a real destination.

   CONTACT INFO CORRECTION (Pass 3): an explicit, direct correction
   flagged the previously-used Instagram-derived WhatsApp number
   (5511922221327 / "(11) 92222-1327") as WRONG. The number is now
   set to +55 11 99934-9773, per that correction, superseding the
   earlier Instagram-based resolution. Suite number (Cj. 309) is
   left as-is since this correction only addressed the phone number.
   ============================================================ */

/* Single source of truth for all contact/location data. Every page consumes
   this object — nothing is hardcoded elsewhere, so a correction here (like the
   phone number fix) propagates everywhere automatically.

   NOTE ON SUITE NUMBER: earlier source material conflicted between "Cj. 306"
   (official website) and "Cj. 309" (Instagram bio). Per explicit instruction,
   this is not Claude's call to make — Cj. 309 is kept here only because the
   user previously confirmed it, not because the conflict is considered
   resolved. If the clinic confirms otherwise, only this object needs to change. */
const CONTACT = {
  address1: "Av. Paulista, 2006",
  address2: "3º andar · Cj. 309",
  city: "São Paulo — SP",
  cep: "01310-926",
  phoneDisplay: "(11) 99934-9773",
  whatsappNumber: "5511999349773",
  telHref: "tel:+5511999349773",
  email: "contato@esteticasalomao.com.br",
  emailHref: "mailto:contato@esteticasalomao.com.br",
  mapsUrl: "https://www.google.com/maps/place/Cl%C3%ADnica+de+Est%C3%A9tica+Salom%C3%A3o/@-23.55882,-46.6616097,17z/data=!3m1!4b1!4m6!3m5!1s0x94ce59a74ef8273b:0x5304326c7ff55b1d!8m2!3d-23.55882!4d-46.6590348!16s%2Fg%2F11rfcxm6fx?entry=ttu&g_ep=EgoyMDI2MDkwOS4wIKXMDSoASAFQAw%3D%3D",
};
const MAPS_URL = CONTACT.mapsUrl; // kept as an alias so existing references below don't need to change

/* Single source of truth for social links — no URL duplicated elsewhere. */
const SOCIAL = {
  instagram: "https://www.instagram.com/esteticasalomao?utm_source=ig_web_button_share_sheet&stkn=ZDNlZDc0MzIxNw==",
  linkedin: "https://br.linkedin.com/in/est%C3%A9tica-salom%C3%A3o-419759213",
  facebook: "https://www.facebook.com/esteticasalomao/?locale=pt_BR",
};

/* Single source of truth for opening hours. Order is deliberately Sunday-first
   per explicit instruction, not the more common Monday-first convention. */
const HOURS = [
  { day: "Domingo", hours: "Fechado" },
  { day: "Segunda-feira", hours: "9h–18h" },
  { day: "Terça-feira", hours: "9h–18h" },
  { day: "Quarta-feira", hours: "9h–18h" },
  { day: "Quinta-feira", hours: "9h–18h" },
  { day: "Sexta-feira", hours: "9h–18h" },
  { day: "Sábado", hours: "9h–13h" },
];

/* Legal page content. Body text is intentionally a clean, honest placeholder —
   not invented legal wording — ready for the clinic's approved final text to
   be dropped in here. Nothing about this appears as raw developer language in
   the rendered page; it reads as ordinary "content coming soon" copy. */
const LEGAL_PLACEHOLDER = "O texto final desta seção está em preparação pela equipe Salomão e será publicado aqui em breve.";
const PRIVACY_SECTIONS = [
  ["1. Informações gerais", LEGAL_PLACEHOLDER],
  ["2. Dados coletados", LEGAL_PLACEHOLDER],
  ["3. Como utilizamos os dados", LEGAL_PLACEHOLDER],
  ["4. Compartilhamento", LEGAL_PLACEHOLDER],
  ["5. Cookies", LEGAL_PLACEHOLDER],
  ["6. Seus direitos", LEGAL_PLACEHOLDER],
  ["7. Contato", `Dúvidas sobre privacidade podem ser enviadas para ${CONTACT.email}.`],
];
const TERMS_SECTIONS = [
  ["1. Aceitação", LEGAL_PLACEHOLDER],
  ["2. Uso do site", LEGAL_PLACEHOLDER],
  ["3. Conteúdo", LEGAL_PLACEHOLDER],
  ["4. Informações sobre tratamentos", LEGAL_PLACEHOLDER],
  ["5. Links externos", LEGAL_PLACEHOLDER],
  ["6. Limitação de responsabilidade", LEGAL_PLACEHOLDER],
  ["7. Contato", `Dúvidas sobre estes termos podem ser enviadas para ${CONTACT.email}.`],
];


function waLink(message) {
  return `https://wa.me/${CONTACT.whatsappNumber}?text=${encodeURIComponent(message)}`;
}
const WA_GENERAL = "Olá, equipe Salomão! Estou pelo site e gostaria de falar com a equipe. Podem me orientar?";
const waTreatment = (name) =>
  `Olá, equipe Salomão! Estou pelo site e gostaria de saber mais sobre ${name} e entender como funciona a avaliação.`;

const CONCERN_PHRASES = {
  "Minha pele": "minha pele", "Meu rosto": "meu rosto", "Meu contorno": "meu contorno",
  "Linhas": "linhas de expressão", "Flacidez": "flacidez", "Minha rotina": "minha rotina de cuidados", "Outro": "outro assunto",
};
function journeyMessage(intent, ctx) {
  const opener = "Olá, equipe Salomão! Estou pelo site";
  let c = "";
  if (ctx && ctx.value) c = ctx.kind === "treatment" ? `Tenho interesse em ${ctx.value}.` : `O que eu gostaria de cuidar: ${CONCERN_PHRASES[ctx.value] || ctx.value.toLowerCase()}.`;
  const join = (...p) => p.filter(Boolean).join(" ");
  switch (intent) {
    case "Quero agendar uma avaliação": return join(`${opener} e gostaria de agendar uma avaliação.`, c, "Poderiam me orientar sobre os próximos horários?");
    case "Quero falar com a equipe": return join(`${opener} e gostaria de falar com a equipe.`, c, "Podem me orientar?");
    case "Quero conhecer um tratamento": return join(`${opener} e gostaria de conhecer um tratamento.`, c, "Podem me contar mais?");
    default: return join(`${opener} e gostaria de entender minhas opções.`, c, "Podem me orientar?");
  }
}

/* ---------------- DATA MODELS ---------------- */
/* `verified` drives internal editorial decisions only (which claims are safe to
   state as fact) — it is never rendered as a visible badge. Customer-facing
   copy for unverified/placeholder content is written as elegant "coming soon"
   language, never as a raw "não verificado" / "DEMO" label. */

/* "Antes de decidir" structure. Only `description` and the few `guide` entries
   come from public sources; every other answer is an explicit pending state. */
const PENDING_CLINICAL = "Conteúdo clínico detalhado será desenvolvido com a equipe Salomão.";
const PENDING_PROTOCOL = "Indicações, expectativas e detalhes do protocolo serão definidos com a equipe clínica.";
const VARIES_GENERIC = "Os resultados variam de pessoa para pessoa.";
const EVALUATION_TEXT = "A indicação é definida em avaliação profissional com a equipe Salomão. Como a avaliação acontece será descrito com a equipe.";

const TREATMENTS = [
  {
    slug: "fios-de-sustentacao",
    name: "Fios de Sustentação",
    short: "Fios de PDO para sustentação e estímulo de colágeno.",
    description:
      "Categoria de destaque da clínica, trabalhada em duas variações — liso e com garras — voltada ao reposicionamento de tecido e ao estímulo de colágeno ao longo do tempo.",
    clinicClaim: "Líder em Fios de PDO em São Paulo",
    guide: {
      melhora: "Sustentação e reposicionamento de tecido, com estímulo de colágeno ao longo do tempo.",
      variar: "O tipo de fio (liso ou com garras) e o planejamento por tecido e objetivo fazem parte da escolha — tema que a própria equipe compartilha em seu conteúdo.",
    },
    verified: true,
    relatedEditorial: ["fio-ideal-nao-e-so-o-nome", "curso-arquitetura-da-beleza"],
  },
  {
    slug: "toxina-botulinica",
    name: "Toxina Botulínica",
    short: "Suavização de linhas de expressão.",
    description:
      "Aplicação facial amplamente utilizada para suavizar linhas de expressão dinâmicas.",
    clinicClaim: null,
    verified: false,
  },
  {
    slug: "preenchimento-ah",
    name: "Preenchimento (AH)",
    short: "Preenchimento com ácido hialurônico.",
    description:
      "Procedimento à base de ácido hialurônico usado para volume e contorno facial.",
    clinicClaim: null,
    verified: false,
    relatedEditorial: ["planejamento-antes-da-seringa"],
  },
  {
    slug: "tratamentos-intimos",
    name: "Tratamentos Íntimos",
    short: "Categoria de estética íntima.",
    description:
      "Categoria de estética íntima, parte do catálogo de cuidados da Salomão.",
    clinicClaim: null,
    verified: false,
  },
  {
    slug: "harmonizacao-facial",
    name: "Harmonização Facial",
    short: "Conjunto de procedimentos para equilíbrio facial.",
    description:
      "Conjunto de procedimentos voltados ao equilíbrio das proporções do rosto.",
    clinicClaim: null,
    verified: false,
  },
  {
    slug: "harmonizacao-corporal",
    name: "Harmonização Corporal",
    short: "Conjunto de procedimentos corporais.",
    description:
      "Parte do catálogo de cuidados da Salomão.",
    clinicClaim: null,
    verified: false,
  },
];

/* Rows of the "Antes de decidir" guide, built from a treatment. */
function guideRows(t) {
  const g = t.guide || {};
  return [
    { key: "oque", label: "O que é", text: t.description, pending: false },
    { key: "paraquem", label: "Para quem pode fazer sentido", text: g.paraQuem || PENDING_PROTOCOL, pending: !g.paraQuem },
    { key: "melhora", label: "O que pode ajudar a melhorar", text: g.melhora || PENDING_CLINICAL, pending: !g.melhora },
    { key: "esperar", label: "O que esperar", text: g.esperar || PENDING_PROTOCOL, pending: !g.esperar },
    { key: "variar", label: "O que pode variar", text: g.variar ? `${VARIES_GENERIC} ${g.variar}` : `${VARIES_GENERIC} Os fatores específicos deste tratamento serão definidos com a equipe clínica.`, pending: false },
    { key: "avaliacao", label: "Como funciona a avaliação", text: g.avaliacao || EVALUATION_TEXT, pending: false },
  ];
}

/* Results: no approved real case material yet, so nothing reads as a real patient
   result. The single entry defines the STRUCTURE every future case will follow. */
const RESULTS = [
  {
    slug: "resultado-01",
    title: "Caso real — em preparação",
    objective: "O que a pessoa buscava, nas palavras dela.",
    treatment: "O que foi feito e por que esse caminho foi escolhido.",
    journey: "Da primeira conversa ao acompanhamento: as etapas do caminho.",
    result: "O que mudou, mostrado com imagens reais e autorizadas.",
    context: "O que pode variar de pessoa para pessoa e o que esperar.",
    verified: false,
  },
];

const TEAM = [
  {
    slug: "ana-paula-dantas",
    name: "Ana Paula Dantas",
    role: "Referência da clínica em Fios de PDO",
    bio:
      "Aparece de forma recorrente como apresentadora principal de conteúdo educativo da clínica e assina o curso/coleção \"Arquitetura da Beleza\". Perfil profissional completo em breve.",
    verified: true,
    relatedEditorial: ["fio-ideal-nao-e-so-o-nome", "curso-arquitetura-da-beleza"],
    relatedTreatment: "fios-de-sustentacao",
  },
  {
    slug: "isana-azevedo",
    name: "Isana Azevedo",
    role: "Especialidade posicionada em lábios (\"Rainha dos Lábios\")",
    bio: "Co-apresenta cursos e lives ao lado da equipe Salomão. Perfil profissional completo em breve.",
    verified: true,
  },
  {
    slug: "marcia-romao",
    name: "Márcia Romão",
    role: "Conteúdo de anatomia aplicada a fios de PDO",
    bio: "Co-apresenta o curso presencial \"Domine os Fios PDO\" ao lado da equipe Salomão. Perfil profissional completo em breve.",
    verified: true,
  },
];

/* The Edit's content model. Deliberately more general than "article" — `type`
   supports the full range of things the clinic publishes (articles, but also
   courses, lectures, announcements, etc.), and `status`/`featured`/`date`/
   `author` are the fields a future admin/CMS layer (e.g. Supabase) would need
   to manage this content without any change to the public-facing components
   below. There is no admin UI in this build — deliberately: building a fake
   dashboard or fake auth would be worse than not having one. This array is
   the mock data source; swapping it for a real API response is the only
   change a real CMS integration would require. Only `status === "published"`
   items are ever shown publicly — draft/scheduled items would simply not
   appear, exactly as they would with a real backend. */
const EDITORIAL = [
  {
    slug: "fio-ideal-nao-e-so-o-nome",
    title: "O fio ideal não é escolhido apenas pelo nome",
    type: "article",
    category: "Fios de PDO",
    readingTime: "3 min",
    date: null,
    author: null,
    status: "published",
    featured: true,
    verified: false,
    relatedTreatment: "fios-de-sustentacao",
    body:
      "Inspirado em um tema já compartilhado pela Salomão — arquitetura do fio, planejamento por tecido e objetivo. O artigo completo chega em breve, direto da equipe.",
  },
  {
    slug: "colageno-e-menopausa",
    title: "Colágeno e menopausa: por que a pele muda",
    type: "article",
    category: "Cuidado",
    readingTime: "4 min",
    date: null,
    author: null,
    status: "published",
    featured: false,
    verified: false,
    body: "Inspirado em um tema já compartilhado pela Salomão sobre menopausa e perda de colágeno. O artigo completo chega em breve.",
  },
  {
    slug: "planejamento-antes-da-seringa",
    title: "Resultado natural não começa na seringa",
    type: "article",
    category: "Método",
    readingTime: "3 min",
    date: null,
    author: null,
    status: "published",
    featured: false,
    verified: false,
    relatedTreatment: "preenchimento-ah",
    body: "Inspirado em uma peça editorial já publicada pela Salomão. O artigo completo chega em breve.",
  },
  {
    slug: "curso-arquitetura-da-beleza",
    title: "Arquitetura da Beleza",
    type: "course",
    category: "Curso",
    readingTime: "Curso",
    date: null,
    author: null,
    status: "published",
    featured: false,
    verified: true,
    relatedTreatment: "fios-de-sustentacao",
    body: "Curso/coleção real assinada pela equipe Salomão, confirmado publicamente. Detalhes de próximas turmas chegam em breve.",
  },
];

/* Human-readable labels for each content type — used for the small category
   badge on The Edit's cards so a course reads as "Curso" and not "article". */
const CONTENT_TYPE_LABELS = {
  article: "Artigo",
  guide: "Guia",
  conversation: "Conversa",
  course: "Curso",
  event: "Evento",
  lecture: "Palestra",
  tip: "Dica",
  announcement: "Novidade",
  news: "Notícia",
};

/* Only published content is ever shown — exactly what a real CMS would do
   with draft/scheduled items. Everything downstream reads from this, never
   from the raw EDITORIAL array, so nothing unpublished can leak onto a page
   or be reached directly by a guessed URL. */
const PUBLISHED_EDITORIAL = EDITORIAL.filter((a) => a.status === "published");

/* ---------------- MEDIA ---------------- */
/* Real, non-AI-generated photography — free-license stock (Pexels License /
   Unsplash License, both confirmed free for commercial use, no attribution
   required) used as TEMPORARY editorial imagery until the clinic supplies its
   own photography. None of these depict real Salomão patients, staff, or
   interiors — copy near each usage makes that explicit. Sourced from
   pexels.com (Anna Shvets treatment series + product/texture photography)
   and images.unsplash.com (Laura Jaeger). */
const MEDIA = {
  // Note: the hero now uses real video (public/videos/hero.mp4) supplied directly
  // by the user, not stock photography — see BackgroundVideo usage in HomePage.
  treatments: [
    { src: "https://images.pexels.com/photos/4586713/pexels-photo-4586713.jpeg?auto=compress&cs=tinysrgb&w=1200", alt: "Fotografia editorial temporária de um tratamento facial" },
    { src: "https://images.pexels.com/photos/4586712/pexels-photo-4586712.jpeg?auto=compress&cs=tinysrgb&w=1200", alt: "Fotografia editorial temporária de aplicação facial" },
    { src: "https://images.pexels.com/photos/4586724/pexels-photo-4586724.jpeg?auto=compress&cs=tinysrgb&w=1200", alt: "Fotografia editorial temporária de tratamento com roller facial" },
    { src: "https://images.pexels.com/photos/4586723/pexels-photo-4586723.jpeg?auto=compress&cs=tinysrgb&w=1200", alt: "Fotografia editorial temporária de cuidado facial em ambiente de clínica" },
    { src: "https://images.pexels.com/photos/4586714/pexels-photo-4586714.jpeg?auto=compress&cs=tinysrgb&w=1200", alt: "Fotografia editorial temporária de atendimento profissional" },
    { src: "https://images.pexels.com/photos/4586721/pexels-photo-4586721.jpeg?auto=compress&cs=tinysrgb&w=1200", alt: "Fotografia editorial temporária de cuidado com ferramenta de beleza" },
  ],
  team: {
    src: "https://images.pexels.com/photos/4586714/pexels-photo-4586714.jpeg?auto=compress&cs=tinysrgb&w=900",
    alt: "Fotografia editorial temporária — retrato ilustrativo, não é a profissional real",
  },
  editorial: [
    { src: "https://images.pexels.com/photos/4586724/pexels-photo-4586724.jpeg?auto=compress&cs=tinysrgb&w=1200", alt: "Fotografia editorial temporária sobre técnica de fios" },
    { src: "https://images.pexels.com/photos/2566853/pexels-photo-2566853.jpeg?auto=compress&cs=tinysrgb&w=1200", alt: "Fotografia editorial temporária, serum e cuidado natural" },
    { src: "https://images.pexels.com/photos/7815016/pexels-photo-7815016.jpeg?auto=compress&cs=tinysrgb&w=1200", alt: "Fotografia editorial temporária, still de produto de skincare" },
  ],
  clinic: {
    src: "https://images.pexels.com/photos/2566853/pexels-photo-2566853.jpeg?auto=compress&cs=tinysrgb&w=1200",
    alt: "Fotografia editorial temporária, atmosfera de cuidado",
  },
  method: {
    src: "https://images.pexels.com/photos/7815016/pexels-photo-7815016.jpeg?auto=compress&cs=tinysrgb&w=1200",
    alt: "Fotografia editorial temporária, precisão e cuidado",
  },
};

/* ---------------- ROUTER (hand-rolled) ---------------- */

const RouterCtx = createContext(null);
function useRouter() {
  return useContext(RouterCtx);
}

function RouterProvider({ children }) {
  const [path, setPath] = useState(() => {
    try {
      return window.location.hash ? window.location.hash.slice(1) : "/";
    } catch {
      return "/";
    }
  });

  // Back-navigation stack and per-path scroll memory. This is a best-effort,
  // in-memory approximation of real browser history/scroll restoration — it
  // works for the app's own <Link>/goBack navigation, and does a reasonable-
  // effort job of following the actual browser back button too, but it is not
  // wired into the real History API's state, so it won't survive a hard page
  // reload. Good enough for "click Voltar, land back near where I was."
  const stackRef = useRef([]);
  const scrollMemory = useRef({});
  const pathRef = useRef(path);
  pathRef.current = path;

  useEffect(() => {
    const onPop = () => {
      try {
        const next = window.location.hash ? window.location.hash.slice(1) : "/";
        // best-effort: if this matches what our own stack expects for a back
        // step, pop it so goBack() stays consistent with the real browser too
        const top = stackRef.current[stackRef.current.length - 1];
        if (top === next) stackRef.current.pop();
        setPath(next);
        requestAnimationFrame(() => {
          window.scrollTo(0, scrollMemory.current[next] ?? 0);
        });
      } catch {}
    };
    window.addEventListener("hashchange", onPop);
    return () => window.removeEventListener("hashchange", onPop);
  }, []);

  const navigate = (to) => {
    scrollMemory.current[pathRef.current] = window.scrollY;
    stackRef.current.push(pathRef.current);
    try {
      window.location.hash = to;
    } catch {}
    setPath(to);
    window.scrollTo({ top: 0, behavior: "auto" });
  };

  const goBack = () => {
    scrollMemory.current[pathRef.current] = window.scrollY;
    const prev = stackRef.current.pop();
    if (prev === undefined) {
      navigate("/");
      return;
    }
    try {
      window.location.hash = prev;
    } catch {}
    setPath(prev);
    requestAnimationFrame(() => {
      window.scrollTo({ top: scrollMemory.current[prev] ?? 0, behavior: "auto" });
    });
  };

  const canGoBack = () => stackRef.current.length > 0;

  return (
    <RouterCtx.Provider value={{ path, navigate, goBack, canGoBack }}>
      {children}
    </RouterCtx.Provider>
  );
}

function Link({ to, className, children, onClick }) {
  const { navigate } = useRouter();
  return (
    <a
      href={`#${to}`}
      className={className}
      onClick={(e) => {
        e.preventDefault();
        if (onClick) onClick();
        navigate(to);
      }}
    >
      {children}
    </a>
  );
}

function matchRoute(path) {
  const parts = path.split("/").filter(Boolean);
  if (parts.length === 0) return { name: "home" };
  if (parts[0] === "clinica") return { name: "clinica" };
  if (parts[0] === "metodo") return { name: "metodo" };
  if (parts[0] === "tratamentos" && parts[1]) return { name: "treatment", slug: parts[1] };
  if (parts[0] === "tratamentos") return { name: "tratamentos" };
  if (parts[0] === "resultados" && parts[1]) return { name: "result", slug: parts[1] };
  if (parts[0] === "resultados") return { name: "resultados" };
  if (parts[0] === "equipe" && parts[1]) return { name: "team-member", slug: parts[1] };
  if (parts[0] === "equipe") return { name: "equipe" };
  if (parts[0] === "editorial" && parts[1]) return { name: "article", slug: parts[1] };
  if (parts[0] === "editorial") return { name: "editorial" };
  if (parts[0] === "my-salomao") return { name: "my-salomao" };
  if (parts[0] === "contato") return { name: "contato" };
  if (parts[0] === "privacidade") return { name: "privacidade" };
  if (parts[0] === "termos") return { name: "termos" };
  return { name: "not-found" };
}

/* ---------------- SHARED CHROME ---------------- */

const NAV = [
  { label: "A Clínica", to: "/clinica" },
  { label: "O Método", to: "/metodo" },
  { label: "Tratamentos", to: "/tratamentos" },
  { label: "Resultados", to: "/resultados" },
  { label: "Equipe", to: "/equipe" },
  { label: "The Edit", to: "/editorial" },
];

function Header({ onOpenJourney }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const [phonePopoverOpen, setPhonePopoverOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const { path } = useRouter();

  useEffect(() => setMenuOpen(false), [path]);

  useEffect(() => {
    if (!menuOpen) return;
    const onKeyDown = (e) => { if (e.key === "Escape") setMenuOpen(false); };
    document.addEventListener("keydown", onKeyDown);
    return () => document.removeEventListener("keydown", onKeyDown);
  }, [menuOpen]);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    window.addEventListener("scroll", onScroll, { passive: true });
    onScroll();
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <>
      <header className={`sal-header ${scrolled ? "is-scrolled" : ""}`}>
        <Link to="/" className="sal-mark">SALOMÃO</Link>

        <nav className="sal-nav">
          {NAV.map((item) => (
            <Link key={item.to} to={item.to} className={path === item.to ? "is-active" : ""}>
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="sal-header-right">
          <Link to="/my-salomao" className="sal-my">My Salomão</Link>
          <button
            className="sal-nav-toggle"
            onClick={() => setMenuOpen((v) => !v)}
            aria-label={menuOpen ? "Fechar menu" : "Abrir menu"}
            aria-expanded={menuOpen}
            aria-controls="sal-mobile-menu"
          >
            <span className={`sal-nav-toggle-icon ${menuOpen ? "is-open" : ""}`}>
              <span />
              <span />
            </span>
          </button>
        </div>
      </header>

      {menuOpen && (
        <div id="sal-mobile-menu" className="sal-drawer" role="dialog" aria-modal="true">
          <div className="sal-drawer-head">
            <span className="sal-mark" style={{ opacity: 1 }}>SALOMÃO</span>
            <button className="sal-drawer-close" onClick={() => setMenuOpen(false)} aria-label="Fechar menu">×</button>
          </div>
          <nav className="sal-drawer-nav">
            {NAV.map((item) => (
              <Link key={item.to} to={item.to} onClick={() => setMenuOpen(false)}>{item.label}</Link>
            ))}
            <Link to="/my-salomao" onClick={() => setMenuOpen(false)}>My Salomão</Link>
            <Link to="/contato" onClick={() => setMenuOpen(false)}>Contato</Link>
          </nav>
          <button
            className="sal-cta-primary sal-drawer-cta"
            onClick={() => { setMenuOpen(false); onOpenJourney(); }}
          >
            Começar sua jornada
          </button>
        </div>
      )}

      {/* fixed phone/whatsapp quick access, bottom-right, present on every page */}
      <div className={`sal-quickcontact ${phonePopoverOpen ? "is-open" : ""}`}>
        {phonePopoverOpen && (
          <div className="sal-phone-popover">
            <a href={waLink(WA_GENERAL)} target="_blank" rel="noreferrer">
              <span>WhatsApp</span><em>{CONTACT.phoneDisplay}</em>
            </a>
            <a href={CONTACT.telHref}>
              <span>Ligar</span><em>{CONTACT.phoneDisplay}</em>
            </a>
          </div>
        )}
        <button
          className="sal-quickcontact-btn"
          onClick={() => setPhonePopoverOpen((v) => !v)}
          aria-label="Fale com a Salomão"
        >
          <span className="sal-quickcontact-dot" />
          <span className="sal-quickcontact-label">Fale com a Salomão</span>
        </button>
      </div>
    </>
  );
}

function Footer() {
  return (
    <footer className="sal-footer">
      <div className="sal-footer-top">
        <span className="sal-mark" style={{ opacity: 1 }}>SALOMÃO</span>
        <p className="sal-footer-statement">Mais você — sempre que precisar.</p>
      </div>
      <div className="sal-footer-grid">
        <div>
          <p className="sal-footer-label">Navegação</p>
          {NAV.map((item) => <Link key={item.to} to={item.to}>{item.label}</Link>)}
        </div>
        <div>
          <p className="sal-footer-label">Salomão</p>
          <Link to="/my-salomao">My Salomão</Link>
          <Link to="/contato">Contato</Link>
        </div>
        <div>
          <p className="sal-footer-label">Acompanhe</p>
          <a href={SOCIAL.instagram} target="_blank" rel="noreferrer">Instagram</a>
          <a href={SOCIAL.linkedin} target="_blank" rel="noreferrer">LinkedIn</a>
          <a href={SOCIAL.facebook} target="_blank" rel="noreferrer">Facebook</a>
        </div>
      </div>
      <div className="sal-footer-legal-row">
        <p className="sal-footer-legal">© Clínica de Estética Salomão.</p>
        <div className="sal-footer-legal-links">
          <Link to="/privacidade">Política de Privacidade</Link>
          <Link to="/termos">Termos de Uso</Link>
        </div>
      </div>
    </footer>
  );
}

/* ---------------- JOURNEY / DISCOVERY MODAL ---------------- */

const GOALS = ["Minha pele", "Meu rosto", "Meu contorno", "Linhas", "Flacidez", "Minha rotina", "Outro"];
const INTENTS = [
  "Quero entender minhas opções",
  "Quero conhecer um tratamento",
  "Quero agendar uma avaliação",
  "Quero falar com a equipe",
];

const JOURNEY_NOTE = "Esta escolha ajuda a orientar a conversa com a equipe. A indicação é definida em avaliação profissional.";
/* A starting point that isn't one of GOALS is a treatment name. */
function toJourneyContext(v) { return v ? { kind: GOALS.includes(v) ? "concern" : "treatment", value: v } : null; }

function JourneyModal({ open, onClose, initialTreatment }) {
  const [step, setStep] = useState(1);
  const [ctx, setCtx] = useState(null);
  const [intent, setIntent] = useState(null);
  const [justPicked, setJustPicked] = useState(null);
  const closeBtnRef = useRef(null);
  const modalRef = useRef(null);
  const lastFocusedRef = useRef(null);

  useEffect(() => {
    if (open) {
      lastFocusedRef.current = document.activeElement;
      const start = toJourneyContext(initialTreatment);
      setCtx(start);
      setStep(start ? 2 : 1); // starting point already known — skip the redundant first question
      setIntent(null);
      setJustPicked(null);
    } else if (lastFocusedRef.current) {
      lastFocusedRef.current.focus();
    }
  }, [open, initialTreatment]);

  useEffect(() => {
    if (open && closeBtnRef.current) closeBtnRef.current.focus();
  }, [open]);

  useEffect(() => {
    if (!open) return;
    const onKeyDown = (e) => {
      if (e.key === "Escape") { onClose(); return; }
      if (e.key !== "Tab" || !modalRef.current) return;
      const focusables = modalRef.current.querySelectorAll('button, a[href]');
      if (!focusables.length) return;
      const first = focusables[0];
      const last = focusables[focusables.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    };
    document.addEventListener("keydown", onKeyDown);
    return () => document.removeEventListener("keydown", onKeyDown);
  }, [open, onClose]);

  if (!open) return null;

  const finalWaHref = waLink(journeyMessage(intent, ctx));
  const label = ctx ? ctx.value : "";
  const cameFromTreatment = Boolean(ctx && ctx.kind === "treatment");

  return (
    <div className="sal-modal-overlay" role="dialog" aria-modal="true" aria-labelledby="sal-modal-heading">
      <div className="sal-modal" ref={modalRef}>
        <button ref={closeBtnRef} className="sal-drawer-close sal-modal-close" onClick={onClose} aria-label="Fechar">×</button>

        {step === 1 && (
          <>
            <p className="sal-modal-step">Comece pelo que importa para você</p>
            <h3 id="sal-modal-heading" className="salomao-serif sal-modal-title">O que você quer cuidar?</h3>
            <p className="sal-modal-support">Você não precisa saber o nome do tratamento.</p>
            <div className="sal-modal-options">
              {GOALS.map((g) => (
                <button
                  key={g}
                  className={`sal-option ${justPicked === g ? "is-selected" : ""}`}
                  onClick={() => {
                    setJustPicked(g);
                    setCtx({ kind: "concern", value: g });
                    // brief pause so the selection registers before the screen moves on
                    setTimeout(() => { setStep(2); setJustPicked(null); }, 320);
                  }}
                >
                  {g}
                </button>
              ))}
            </div>
            <p className="sal-modal-note">{JOURNEY_NOTE}</p>
          </>
        )}

        {step === 2 && (
          <>
            <p className="sal-modal-step">Sem pressa</p>
            <p className="sal-modal-context">
              {cameFromTreatment ? "Você está vendo" : "Ponto de partida"}: <strong>{label}</strong>
            </p>
            <h3 id="sal-modal-heading" className="salomao-serif sal-modal-title">O que faz sentido agora?</h3>
            <div className="sal-modal-options">
              {INTENTS.map((i) => (
                <button key={i} className="sal-option" onClick={() => { setIntent(i); setStep(3); }}>
                  {i}
                </button>
              ))}
            </div>
            {!cameFromTreatment && (
              <button className="sal-modal-back" onClick={() => setStep(1)}>Voltar</button>
            )}
          </>
        )}

        {step === 3 && (
          <>
            <p className="sal-modal-step">Próximo passo</p>
            <h3 id="sal-modal-heading" className="salomao-serif sal-modal-title">Vamos conversar.</h3>
            <p className="sal-modal-support">
              Abrimos o WhatsApp com uma mensagem pronta, já com o que você escolheu:
              <em> {label}</em> · <em>{intent}</em>. Você pode ajustar o texto antes de enviar.
            </p>
            <a href={finalWaHref} target="_blank" rel="noreferrer" className="sal-cta-primary sal-modal-cta">
              Abrir WhatsApp
            </a>
            <p className="sal-modal-note">{JOURNEY_NOTE}</p>
            <button className="sal-modal-back" onClick={() => setStep(2)}>Voltar</button>
          </>
        )}
      </div>
    </div>
  );
}

/* ---------------- PAGE SHELL ---------------- */

function BackLink() {
  const { goBack } = useRouter();
  return (
    <button className="sal-back-link" onClick={goBack}>
      <span className="sal-back-arrow">←</span> Voltar
    </button>
  );
}

function PageHero({ eyebrow, title, support }) {
  return (
    <div className="sal-page-hero">
      <BackLink />
      <div className="sal-eyebrow-rule is-visible">
        <span />
        <p>{eyebrow}</p>
      </div>
      <h1 className="salomao-serif sal-page-title">{title}</h1>
      {support && <p className="sal-page-support">{support}</p>}
    </div>
  );
}

function useIsMobile(breakpoint = 980) {
  const [isMobile, setIsMobile] = useState(
    typeof window !== "undefined" ? window.innerWidth < breakpoint : false
  );
  useEffect(() => {
    const mq = window.matchMedia(`(max-width: ${breakpoint - 1}px)`);
    const onChange = (e) => setIsMobile(e.matches);
    setIsMobile(mq.matches);
    mq.addEventListener ? mq.addEventListener("change", onChange) : mq.addListener(onChange);
    return () => {
      mq.removeEventListener ? mq.removeEventListener("change", onChange) : mq.removeListener(onChange);
    };
  }, [breakpoint]);
  return isMobile;
}

function TreatmentGuide({ treatment, compact }) {
  const rows = guideRows(treatment);
  if (compact) {
    const shown = rows.filter((r) => (r.key === "melhora" || r.key === "variar") && !r.pending);
    return (
      <div className="sal-guide-compact">
        <p className="sal-guide-compact-title">Antes de decidir</p>
        {shown.map((r) => (
          <div key={r.key} className="sal-guide-compact-row">
            <p className="sal-guide-compact-label">{r.label}</p>
            <p className="sal-guide-compact-text">{r.key === "variar" && !(treatment.guide && treatment.guide.variar) ? VARIES_GENERIC : r.text}</p>
          </div>
        ))}
        {rows.some((r) => r.pending) && <p className="sal-guide-pending">{PENDING_PROTOCOL}</p>}
      </div>
    );
  }
  return (
    <dl className="sal-guide">
      {rows.map((r) => (
        <div key={r.key} className="sal-guide-row">
          <dt className="salomao-serif sal-guide-label">{r.label}</dt>
          <dd className={`sal-guide-text ${r.pending ? "is-pending" : ""}`}>{r.text}</dd>
        </div>
      ))}
    </dl>
  );
}

function TreatmentExplorer() {
  const [active, setActive] = useState(0);
  const isMobile = useIsMobile(980);
  const t = TREATMENTS[active];
  const img = MEDIA.treatments[active % MEDIA.treatments.length];

  // Mobile/tablet: accordion — content expands directly under the tapped name,
  // and the active (brown) line sits under the expanded content, not the name.
  if (isMobile) {
    return (
      <div className="sal-explorer-accordion">
        {TREATMENTS.map((item, i) => {
          const isOpen = i === active;
          const itemImg = MEDIA.treatments[i % MEDIA.treatments.length];
          return (
            <div key={item.slug} className="sal-accordion-item">
              <button
                className="sal-accordion-trigger"
                onClick={() => setActive(isOpen ? active : i)}
                aria-expanded={isOpen}
              >
                <span className="salomao-serif sal-explorer-item-name">{item.name}</span>
                <span className={`sal-accordion-chevron ${isOpen ? "is-open" : ""}`}>→</span>
              </button>
              <div className={`sal-accordion-panel ${isOpen ? "is-open" : ""}`}>
                <div className="sal-accordion-panel-inner">
                  <div className="sal-explorer-swatch">
                    <img className="sal-media-img" src={itemImg.src} alt={itemImg.alt} loading="lazy" />
                    <span className="sal-explorer-swatch-label">{String(i + 1).padStart(2, "0")}</span>
                  </div>
                  <p className="sal-explorer-short">{item.short}</p>
                  <TreatmentGuide treatment={item} compact />
                  <div className="sal-cta-row" style={{ marginTop: 14 }}>
                    <Link to={`/tratamentos/${item.slug}`} className="sal-inline-link">Entender este tratamento →</Link>
                  </div>
                  <div className="sal-accordion-activeline" />
                </div>
              </div>
            </div>
          );
        })}
      </div>
    );
  }

  // Desktop: unchanged — name list on the left, live preview on the right.
  return (
    <div className="sal-explorer">
      <div className="sal-explorer-list">
        {TREATMENTS.map((item, i) => (
          <button
            key={item.slug}
            className={`sal-explorer-item ${i === active ? "is-active" : ""}`}
            onMouseEnter={() => setActive(i)}
            onFocus={() => setActive(i)}
            onClick={() => setActive(i)}
          >
            <span className="sal-explorer-item-name salomao-serif">{item.name}</span>
            <span className="sal-explorer-item-arrow">→</span>
          </button>
        ))}
      </div>
      <div className="sal-explorer-preview">
        <div className="sal-explorer-swatch">
          <img key={img.src} className="sal-media-img sal-explorer-img" src={img.src} alt={img.alt} loading="lazy" />
          <span className="sal-explorer-swatch-label">{String(active + 1).padStart(2, "0")}</span>
        </div>
        <p className="sal-explorer-short">{t.short}</p>
        <TreatmentGuide treatment={t} compact />
        <div className="sal-cta-row" style={{ marginTop: 18 }}>
          <Link to={`/tratamentos/${t.slug}`} className="sal-inline-link">Entender este tratamento →</Link>
        </div>
      </div>
    </div>
  );
}

/* A result is a story with context, not just a before/after. Shows the STRUCTURE
   every real case will follow; frames are reserved for real, authorised material. */
function CaseStructure({ r, showLink }) {
  const [ref, visible] = useReveal();
  const steps = [["Objetivo", r.objective], ["Tratamento", r.treatment], ["Jornada", r.journey], ["Resultado", r.result], ["Contexto", r.context]];
  return (
    <div ref={ref} className={`sal-case ${visible ? "is-in" : ""}`}>
      <p className="sal-case-flag">Caso real — material da clínica após aprovação</p>
      <div className="sal-case-frames" role="img" aria-label="Espaço reservado para imagens reais, inseridas com autorização">
        <div className="sal-case-frame"><span className="salomao-serif">Antes</span></div>
        <div className="sal-case-frame"><span className="salomao-serif">Depois</span></div>
      </div>
      <ol className="sal-case-flow">
        {steps.map(([label, text]) => (
          <li key={label} className="sal-case-step">
            <p className="salomao-serif sal-case-step-label">{label}</p>
            <p className="sal-case-step-text">{text}</p>
          </li>
        ))}
      </ol>
      {showLink && <Link to={`/resultados/${r.slug}`} className="sal-inline-link">Ver a estrutura do caso →</Link>}
    </div>
  );
}

function ResultsArchive({ showLink = true }) {
  return <CaseStructure r={RESULTS[0]} showLink={showLink} />;
}


function SalomaoAgoraStrip() {
  const [ref, visible] = useReveal();
  const slots = [["Novidade", "Lançamentos e avisos da clínica"], ["Evento", "Encontros, lives e aulas"], ["Conteúdo", "Novas leituras da The Edit"]];
  return (
    <section ref={ref} className={`sal-agora ${visible ? "sal-reveal-in" : "sal-reveal-pre"}`}>
      <div className="sal-eyebrow-rule is-visible">
        <span />
        <p>Salomão agora · prévia</p>
      </div>
      <p className="salomao-serif sal-agora-lead">O que está acontecendo por aqui.</p>
      <div className="sal-agora-row">
        {slots.map(([type, desc]) => (
          <div key={type} className="sal-agora-item">
            <span className="sal-agora-type">{type}</span>
            <span className="salomao-serif sal-agora-title">{desc}</span>
          </div>
        ))}
      </div>
      <p className="sal-agora-note">Prévia do conceito. Quando houver novidades reais da equipe, elas aparecem aqui.</p>
    </section>
  );
}

function BeliefSection() {
  const [ref, visible] = useReveal();
  return (
    <section ref={ref} className={`sal-belief-cinematic ${visible ? "is-revealed" : ""}`}>
      <BackgroundVideo
        src="/videos/belief-skincare.mp4"
        poster="/videos/belief-poster.jpg"
        objectPositionDesktop="58% 62%"
        objectPositionMobile="55% 68%"
      />
      <div className="sal-belief-content">
        <div className="sal-eyebrow-rule is-visible">
          <span />
          <p>Uma outra forma de cuidar</p>
        </div>
        <h2 className="salomao-serif sal-belief-title">A estética começa antes do espelho.</h2>
        <p className="sal-body-text-light" style={{ maxWidth: 420 }}>
          O primeiro passo não é escolher um procedimento. É entender o que você procura.
        </p>
      </div>
    </section>
  );
}

function ProductRevealSection() {
  const [ref, visible] = useReveal();
  const rows = ["Seu próximo momento", "Seu retorno", "Conteúdo para você"];
  return (
    <section ref={ref} className={`sal-section sal-section-dark sal-product-reveal ${visible ? "sal-reveal-in" : "sal-reveal-pre"}`}>
      <div className="sal-product-reveal-text">
        <div className="sal-eyebrow-rule is-visible">
          <span />
          <p>My Salomão · conceito</p>
        </div>
        <h2 className="salomao-serif sal-section-title">Sua jornada não termina na clínica.</h2>
        <p className="sal-body-text-light" style={{ maxWidth: 420 }}>
          Uma ideia para quem faz parte da jornada Salomão: um espaço pessoal para acompanhar
          os próximos momentos e continuar conectado. Ainda em desenvolvimento.
        </p>
        <Link to="/my-salomao" className="sal-cta-primary" style={{ display: "inline-block", marginTop: 28 }}>
          Conhecer a ideia
        </Link>
      </div>
      <div className="sal-phone-mock">
        <div className="sal-phone-mock-frame">
          <div className="sal-phone-mock-notch" />
          <p className="sal-phone-mock-heading">Sua jornada</p>
          {rows.map((t, i) => (
            <div key={t} className={`sal-phone-mock-row ${visible ? "is-in" : ""}`} style={{ transitionDelay: `${0.35 + i * 0.14}s` }}>
              <span className="sal-phone-mock-dot" />
              <span>{t}</span>
            </div>
          ))}
          <p className="sal-phone-mock-caption">Ilustração do conceito</p>
        </div>
      </div>
    </section>
  );
}

function TeamPhotoFrame({ className }) {
  return (
    <div className={className}>
      <img className="sal-media-img" src={MEDIA.team.src} alt={MEDIA.team.alt} loading="lazy" />
      <span className="sal-team-photo-caption">Foto ilustrativa — retrato oficial em breve</span>
    </div>
  );
}

function VerifiedTag({ verified }) {
  if (verified) return null;
  return <span className="sal-tag sal-tag-soon">Conteúdo em breve</span>;
}

/* ---------------- PAGES ---------------- */

/* ---------------- BACKGROUND VIDEO ---------------- */
/* Reusable full-bleed cinematic background video. Renders a static poster
   instead of the moving video when prefers-reduced-motion is set. Object
   position is tunable per-breakpoint via CSS custom properties so the subject
   (a face, or hands/action) stays framed correctly on both desktop and mobile. */

function BackgroundVideo({ src, poster, className, overlay = true, objectPositionDesktop = "50% 35%", objectPositionMobile = "50% 35%" }) {
  const [reducedMotion, setReducedMotion] = useState(false);

  useEffect(() => {
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    setReducedMotion(mq.matches);
    const onChange = (e) => setReducedMotion(e.matches);
    mq.addEventListener ? mq.addEventListener("change", onChange) : mq.addListener(onChange);
    return () => {
      mq.removeEventListener ? mq.removeEventListener("change", onChange) : mq.removeListener(onChange);
    };
  }, []);

  const style = {
    "--sal-objpos-desktop": objectPositionDesktop,
    "--sal-objpos-mobile": objectPositionMobile,
  };

  return (
    <div className={`sal-bgvideo ${className || ""}`} style={style}>
      {reducedMotion ? (
        <img className="sal-bgvideo-media" src={poster} alt="" loading="lazy" />
      ) : (
        <video
          className="sal-bgvideo-media"
          src={src}
          poster={poster}
          autoPlay
          muted
          loop
          playsInline
          preload="metadata"
        />
      )}
      {overlay && <div className="sal-bgvideo-overlay" />}
    </div>
  );
}

/* Four-part method, shared by the home summary and /metodo. "Acompanhar" is the
   intention of continuity; My Salomão is presented separately as a concept. */
const METHOD_STEPS = [
  ["Entender", "Começar por aquilo que você busca — suas prioridades, expectativas e intenção."],
  ["Planejar", "Transformar essa intenção em um caminho pensado com orientação profissional."],
  ["Refinar", "Considerar o que faz sentido para você, em vez de tratar todas as pessoas da mesma forma."],
  ["Acompanhar", "O cuidado não termina no momento do procedimento."],
];

function HomePage({ onOpenJourney, onOpenJourneyFor }) {
  const [scrollY, setScrollY] = useState(0);

  useEffect(() => {
    const onScroll = () => setScrollY(window.scrollY);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const heroProgress = Math.min(scrollY / 600, 1);
  const reducedMotion = typeof window !== "undefined" && window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  // Per explicit direction: the video itself never fades or dims — it stays fully
  // visible throughout. Only a separate brightness scrim changes: darker/more
  // cinematic at the top, gradually lighter as the hero scrolls away, so the
  // visual "reveals itself" rather than the whole hero disappearing.
  const heroBrightnessStyle = reducedMotion ? { opacity: 0.3 } : { opacity: 0.38 - heroProgress * 0.26 };
  const heroTextStyle = reducedMotion ? {} : {
    transform: `translateY(${heroProgress * 40}px)`,
    opacity: 1 - heroProgress * 0.7,
  };

  return (
    <>
      <section className="sal-hero sal-hero-cinematic">
        <BackgroundVideo
          src="/videos/hero.mp4"
          poster="/videos/hero-poster.jpg"
          objectPositionDesktop="62% 38%"
          objectPositionMobile="58% 30%"
          className="sal-hero-bgvideo"
        />
        <div className="sal-hero-brightness-scrim" style={heroBrightnessStyle} />
        <div className="sal-hero-text" style={heroTextStyle}>
          <div className="sal-eyebrow-rule is-visible">
            <span />
            <p>Clínica de Estética · Avenida Paulista</p>
          </div>
          <h1 className="sal-headline salomao-serif">
            <span className="line"><span>MAIS</span></span>
            <span className="line"><span className="accent">você.</span></span>
          </h1>
          <p className="sal-support is-visible">Estética personalizada para realçar o que já é seu.</p>
          <div className="sal-cta-row is-visible">
            <button className="sal-cta-primary" onClick={onOpenJourney}>Começar sua jornada</button>
            <Link to="/clinica" className="sal-cta-secondary sal-cta-secondary-oncontrast">Conhecer a Salomão</Link>
          </div>
        </div>
      </section>

      <Section eyebrow="O que é" title="Uma clínica na Avenida Paulista" size="quiet">
        <p className="sal-body-text">
          A Salomão é uma clínica de estética localizada no coração da Avenida Paulista, em São Paulo.
        </p>
        <p className="sal-body-text" style={{ marginTop: 14 }}>
          Antes de escolher um caminho, vem o entendimento. É por aí que este espaço convida você a começar.
        </p>
      </Section>

      <BeliefSection />

      <Section eyebrow="O método" title="Entender. Planejar. Refinar. Acompanhar.">
        <p className="sal-body-text" style={{ marginBottom: 28 }}>
          Antes do procedimento, vem o entendimento.
        </p>
        <div className="sal-method-grid">
          {METHOD_STEPS.map(([w, d]) => (
            <div key={w} className="sal-method-item">
              <p className="salomao-serif sal-method-word">{w}</p>
              <p className="sal-method-desc">{d}</p>
            </div>
          ))}
        </div>
        <Link to="/metodo" className="sal-inline-link">Conhecer o método →</Link>
      </Section>

      <Section eyebrow="Descubra" title="O que você quer cuidar?" tone="sun">
        <p className="sal-body-text" style={{ marginBottom: 20 }}>
          Comece pelo que importa para você. Você não precisa saber o nome do tratamento.
        </p>
        <div className="sal-goal-row">
          {GOALS.map((g) => (
            <button key={g} className="sal-option" onClick={() => onOpenJourneyFor(g)}>{g}</button>
          ))}
        </div>
      </Section>

      <Section eyebrow="Tratamentos" title="Cada rosto. Um caminho." tone="blush">
        <p className="sal-body-text" style={{ marginBottom: 28 }}>
          Escolha um para entender o que é, o que esperar e o que pode variar antes de decidir.
        </p>
        <TreatmentExplorer />
        <Link to="/tratamentos" className="sal-inline-link" style={{ marginTop: 24, display: "inline-block" }}>Ver todos os tratamentos →</Link>
      </Section>

      <section className="sal-quiet-statement">
        <p className="salomao-serif sal-quiet-statement-text">Antes de decidir, entenda.</p>
        <p className="sal-quiet-statement-note">Não há pressa para escolher.</p>
      </section>

      <Section eyebrow="Resultados" title="O resultado também tem uma história." dark>
        <p className="sal-body-text" style={{ marginBottom: 28 }}>
          Veja o resultado com contexto: o objetivo, o caminho e o que pode variar. Casos reais serão inseridos com autorização.
        </p>
        <ResultsArchive showLink={false} />
        <Link to="/resultados" className="sal-inline-link" style={{ marginTop: 20, display: "inline-block" }}>Ver como os casos serão contados →</Link>
      </Section>

      <Section eyebrow="A equipe" title="Por trás de cada experiência, existem pessoas." tone="sienna">
        <p className="sal-body-text" style={{ marginBottom: 28 }}>
          Saber quem cuida também ajuda a decidir. Conheça os profissionais que fazem parte da Salomão.
        </p>
        <div className="sal-team-featured">
          <Link to={`/equipe/${TEAM[0].slug}`} className="sal-team-featured-main">
            <TeamPhotoFrame className="sal-team-featured-photo" />
            <p className="salomao-serif sal-team-featured-name">{TEAM[0].name}</p>
            <p className="sal-team-role">{TEAM[0].role}</p>
          </Link>
          <div className="sal-team-featured-list">
            {TEAM.slice(1).map((p) => (
              <Link key={p.slug} to={`/equipe/${p.slug}`} className="sal-team-featured-item">
                <span className="salomao-serif">{p.name}</span>
                <span className="sal-team-role">{p.role}</span>
              </Link>
            ))}
          </div>
        </div>
        <Link to="/equipe" className="sal-inline-link">Conhecer a equipe →</Link>
      </Section>

      <Section eyebrow="The Edit" title="Entender também faz parte do cuidado." size="major">
        <p className="sal-body-text" style={{ marginBottom: 28 }}>
          Explicações, guias e conversas para decidir com mais clareza.
        </p>
        {(() => {
          const featured = PUBLISHED_EDITORIAL.find((a) => a.featured) || PUBLISHED_EDITORIAL[0];
          const side = PUBLISHED_EDITORIAL.filter((a) => a.slug !== featured.slug).slice(0, 2);
          const featuredImgIdx = EDITORIAL.findIndex((x) => x.slug === featured.slug);
          return (
            <div className="sal-magazine">
              <Link to={`/editorial/${featured.slug}`} className="sal-magazine-feature">
                <div className="sal-magazine-feature-photo">
                  <img className="sal-media-img" src={MEDIA.editorial[featuredImgIdx % MEDIA.editorial.length].src} alt={MEDIA.editorial[featuredImgIdx % MEDIA.editorial.length].alt} loading="lazy" />
                </div>
                <p className="sal-editorial-cat">{CONTENT_TYPE_LABELS[featured.type]} · {featured.category} · {featured.readingTime}</p>
                <p className="salomao-serif sal-magazine-feature-title">{featured.title}</p>
              </Link>
              <div className="sal-magazine-side">
                {side.map((a) => (
                  <Link key={a.slug} to={`/editorial/${a.slug}`} className="sal-magazine-side-item">
                    <p className="sal-editorial-cat">{CONTENT_TYPE_LABELS[a.type]} · {a.category} · {a.readingTime}</p>
                    <p className="salomao-serif">{a.title}</p>
                  </Link>
                ))}
              </div>
            </div>
          );
        })()}
        <Link to="/editorial" className="sal-inline-link">Entender antes de escolher →</Link>
      </Section>

      <SalomaoAgoraStrip />

      <ProductRevealSection />

      <Section eyebrow="A casa" title="No coração da Paulista." size="quiet">
        <a href={MAPS_URL} target="_blank" rel="noreferrer" className="sal-address-link sal-body-text">
          {CONTACT.address1} · {CONTACT.address2}<br />{CONTACT.city}
        </a>
        <div className="sal-cta-row" style={{ marginTop: 24 }}>
          <a
            className="sal-cta-secondary"
            href={MAPS_URL}
            target="_blank"
            rel="noreferrer"
          >
            Como chegar
          </a>
          <Link to="/contato" className="sal-cta-secondary">Fale com a equipe</Link>
        </div>
      </Section>

      <Section eyebrow="Comece" title="Quer começar?" center dark size="quiet">
        <p className="sal-body-text" style={{ margin: "0 auto 20px" }}>Comece pelo que importa para você.</p>
        <button className="sal-cta-primary" onClick={onOpenJourney} style={{ marginTop: 12 }}>
          Começar sua jornada
        </button>
      </Section>
    </>
  );
}

function useReveal() {
  const [visible, setVisible] = useState(false);
  const ref = (node) => {
    if (!node || node.__salObserved) return;
    node.__salObserved = true;
    const obs = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            setVisible(true);
            obs.disconnect();
          }
        });
      },
      { threshold: 0.18 }
    );
    obs.observe(node);
  };
  return [ref, visible];
}

function Section({ eyebrow, title, children, dark, center, tone, size }) {
  const [ref, visible] = useReveal();
  const toneClass = tone ? `sal-section-${tone}` : dark ? "sal-section-dark" : "";
  const sizeClass = size ? `sal-section-${size}` : "";
  return (
    <section ref={ref} className={`sal-section ${toneClass} ${sizeClass} ${center ? "sal-section-center" : ""} ${visible ? "sal-reveal-in" : "sal-reveal-pre"}`}>
      <div className="sal-eyebrow-rule is-visible">
        <span />
        <p>{eyebrow}</p>
      </div>
      <h2 className="salomao-serif sal-section-title">{title}</h2>
      {children}
    </section>
  );
}

function ClinicaPage() {
  return (
    <>
      <PageHero eyebrow="A Clínica" title="Bem-vinda à Salomão." support="Um espaço dedicado ao cuidado estético, com uma abordagem humana e personalizada." />
      <div className="sal-fullbleed">
        <img className="sal-media-img" src={MEDIA.clinic.src} alt={MEDIA.clinic.alt} loading="lazy" />
        <span className="sal-fullbleed-caption">Imagem editorial temporária — atmosfera, não a clínica real</span>
      </div>
      <Section eyebrow="Quem somos" title="Cuidado, com intenção.">
        <p className="sal-body-text">
          A Salomão descreve sua proposta como cuidado estético moderno e personalizado, com uma
          abordagem humana e acolhedora — construída em torno de cuidado, personalização,
          profissionalismo, bem-estar, autoestima e resultados.
        </p>
      </Section>
      <Section eyebrow="A nossa história" title="Linha do tempo">
        <p className="sal-body-text">Uma linha do tempo com os marcos da Salomão chega em breve.</p>
      </Section>
      <Section eyebrow="A casa" title="Paulista, 2006." dark>
        <a href={MAPS_URL} target="_blank" rel="noreferrer" className="sal-address-link sal-body-text-light">
          {CONTACT.address1} · {CONTACT.address2}<br />{CONTACT.city}
        </a>
      </Section>
      <Section eyebrow="O que oferecemos" title="Cuidado em diferentes formas.">
        <div className="sal-treatment-grid">
          {TREATMENTS.map((t) => (
            <Link key={t.slug} to={`/tratamentos/${t.slug}`} className="sal-treatment-card">
              <p className="salomao-serif sal-treatment-name">{t.name}</p>
              <span className="sal-card-arrow">→</span>
            </Link>
          ))}
        </div>
      </Section>
      <Section eyebrow="As pessoas" title="Conheça quem cuida." tone="sienna">
        <div className="sal-team-row">
          {TEAM.map((p) => (
            <Link key={p.slug} to={`/equipe/${p.slug}`} className="sal-team-card">
              <TeamPhotoFrame className="sal-team-photo" />
              <p className="salomao-serif">{p.name}</p>
            </Link>
          ))}
        </div>
      </Section>
      <Section eyebrow="Contato" title="Vamos conversar?" dark>
        <p className="sal-body-text-light" style={{ marginBottom: 20 }}>{CONTACT.phoneDisplay}</p>
        <a href={waLink(WA_GENERAL)} target="_blank" rel="noreferrer" className="sal-cta-secondary sal-cta-secondary-oncontrast">Fale com a equipe</a>
      </Section>
    </>
  );
}

function MethodSequence({ steps }) {
  const [revealedCount, setRevealedCount] = useState(0);
  const [trackHeight, setTrackHeight] = useState(0);
  const itemRefs = useRef([]);
  const sectionRef = useRef(null);

  useEffect(() => {
    const measure = () => {
      if (sectionRef.current) {
        // matches the track line's own top:90/bottom:110 offsets in CSS —
        // percentage height won't resolve on an absolutely-positioned child of
        // an auto-height container, so the fill's height is computed in real
        // pixels instead.
        setTrackHeight(Math.max(0, sectionRef.current.offsetHeight - 90 - 110));
      }
    };
    measure();
    window.addEventListener("resize", measure);
    return () => window.removeEventListener("resize", measure);
  }, [steps.length]);

  useEffect(() => {
    const observers = itemRefs.current.map((node, i) => {
      if (!node) return null;
      const obs = new IntersectionObserver(
        (entries) => {
          entries.forEach((e) => {
            if (e.isIntersecting) {
              // the line only ever grows forward — scrolling back up doesn't
              // retract it, so the "journey so far" always stays visible
              setRevealedCount((prev) => Math.max(prev, i + 1));
            }
          });
        },
        { threshold: 0.4 }
      );
      obs.observe(node);
      return obs;
    });
    return () => observers.forEach((o) => o && o.disconnect());
  }, [steps.length]);

  const progress = steps.length ? revealedCount / steps.length : 0;

  return (
    <section ref={sectionRef} className="sal-method-sequence">
      {steps.map(([w, d], i) => (
        <div
          key={w}
          ref={(node) => { itemRefs.current[i] = node; }}
          className={`sal-method-seq-item ${i < revealedCount ? "is-revealed" : ""}`}
          style={{ marginLeft: `${i * 6}%` }}
        >
          <span className="sal-method-seq-index">0{i + 1}</span>
          <p className="salomao-serif sal-method-seq-word">{w}</p>
          <p className="sal-method-seq-desc">{d}</p>
        </div>
      ))}
      <div className="sal-method-seq-line" />
      <div className="sal-method-seq-line-fill" style={{ height: `${progress * trackHeight}px` }} />
    </section>
  );
}

function MetodoPage() {
  return (
    <>
      <PageHero eyebrow="O Método" title="Antes do procedimento, vem o entendimento." support="Cada pessoa chega com uma intenção diferente. Por isso, a jornada começa entendendo o que você busca." />
      <div className="sal-fullbleed sal-fullbleed-short">
        <img className="sal-media-img" src={MEDIA.method.src} alt={MEDIA.method.alt} loading="lazy" />
      </div>
      <MethodSequence steps={METHOD_STEPS} />
      <Section eyebrow="Continuidade" title="Cuidado é continuidade." tone="sun">
        <p className="sal-body-text" style={{ maxWidth: 480 }}>
          A ideia é que o cuidado continue depois do procedimento. My Salomão é a continuação
          imaginada dessa experiência — ainda em desenvolvimento.
        </p>
        <Link to="/my-salomao" className="sal-inline-link">Conhecer o conceito →</Link>
      </Section>
    </>
  );
}

function TratamentosPage({ onOpenJourneyFor }) {
  return (
    <>
      <PageHero eyebrow="Tratamentos" title="O cuidado certo começa com a pergunta certa." support="Você não precisa chegar sabendo qual tratamento procura. Comece pelo que quer mudar ou, se preferir, explore por categoria." />
      <Section eyebrow="Comece pelo que importa para você" title="O que você quer cuidar?" dark>
        <div className="sal-goal-row">
          {GOALS.map((g) => (
            <button key={g} className="sal-option" onClick={() => onOpenJourneyFor(g)}>{g}</button>
          ))}
        </div>
      </Section>
      <Section eyebrow="Ou explore por categoria" title="Entender antes de escolher." tone="blush">
        <TreatmentExplorer />
      </Section>
    </>
  );
}

function TreatmentDetailPage({ slug, onOpenJourneyFor }) {
  const t = TREATMENTS.find((x) => x.slug === slug);
  if (!t) return <NotFoundPage />;
  const idx = TREATMENTS.findIndex((x) => x.slug === slug);
  const img = MEDIA.treatments[idx % MEDIA.treatments.length];
  return (
    <>
      <PageHero eyebrow="Tratamento" title={t.name} />
      <div className="sal-fullbleed sal-fullbleed-short">
        <img className="sal-media-img" src={img.src} alt={img.alt} loading="lazy" />
      </div>
      <Section eyebrow="Antes de decidir" title="Entender antes de escolher.">
        <TreatmentGuide treatment={t} />
        {t.clinicClaim && (
          <p className="sal-public-claim">
            Como a própria clínica se posiciona publicamente: “{t.clinicClaim}”.
          </p>
        )}
      </Section>
      <Section eyebrow="Conversar sobre isso" title="Quando fizer sentido, a conversa começa." dark>
        <p className="sal-body-text" style={{ maxWidth: 480 }}>
          O próximo passo é conversar com a equipe Salomão para entender se este tratamento
          é indicado para o seu caso. Sem pressa.
        </p>
        <div className="sal-cta-row" style={{ marginTop: 24 }}>
          <button className="sal-cta-primary" onClick={() => onOpenJourneyFor(t.name)}>Começar sua jornada</button>
          <a href={waLink(waTreatment(t.name))} target="_blank" rel="noreferrer" className="sal-cta-secondary">
            Falar com a equipe
          </a>
        </div>
      </Section>
      {t.relatedEditorial && t.relatedEditorial.length > 0 && (
        <Section eyebrow="Para saber mais" title="Continue explorando" tone="sienna">
          <div className="sal-related-row">
            {t.relatedEditorial.map((s) => {
              const a = PUBLISHED_EDITORIAL.find((x) => x.slug === s);
              if (!a) return null;
              return (
                <Link key={s} to={`/editorial/${s}`} className="sal-related-item">
                  <span className="sal-agora-type">{CONTENT_TYPE_LABELS[a.type]}</span>
                  <span className="salomao-serif">{a.title}</span>
                  <span className="sal-related-arrow">→</span>
                </Link>
              );
            })}
          </div>
        </Section>
      )}
    </>
  );
}

function ResultadosPage() {
  return (
    <>
      <PageHero eyebrow="Resultados" title="O resultado também tem uma história." support="Cada caso será apresentado com o objetivo, o caminho e o contexto — não só com antes e depois. Veja o resultado com contexto." />
      <Section eyebrow="Como os casos serão contados" title="Da pessoa ao contexto." dark>
        <ResultsArchive />
      </Section>
    </>
  );
}

function ResultDetailPage({ slug }) {
  const r = RESULTS.find((x) => x.slug === slug);
  if (!r) return <NotFoundPage />;
  return (
    <>
      <PageHero eyebrow="Caso" title={r.title} support="Veja o resultado com contexto." />
      <Section eyebrow="Estrutura do caso" title="Objetivo, caminho e contexto." dark>
        <CaseStructure r={r} showLink={false} />
        <p className="sal-disclaimer">
          Resultados variam por pessoa. Nenhuma informação clínica específica é garantida.
        </p>
      </Section>
    </>
  );
}

function EquipePage() {
  return (
    <>
      <PageHero eyebrow="A Equipe" title="Por trás da técnica, existe uma pessoa." support="Saber quem cuida também ajuda a decidir. Conheça os profissionais que fazem parte da experiência Salomão." />
      <Section eyebrow="Diretório" title="Explorar" tone="sienna">
        <div className="sal-team-row">
          {TEAM.map((p) => (
            <Link key={p.slug} to={`/equipe/${p.slug}`} className="sal-team-card">
              <TeamPhotoFrame className="sal-team-photo" />
              <p className="salomao-serif">{p.name}</p>
              <p className="sal-team-role">{p.role}</p>
            </Link>
          ))}
        </div>
      </Section>
    </>
  );
}

function TeamDetailPage({ slug, onOpenJourney }) {
  const p = TEAM.find((x) => x.slug === slug);
  if (!p) return <NotFoundPage />;
  return (
    <>
      <PageHero eyebrow="Perfil" title={p.name} support={p.role} />
      <Section eyebrow="Sobre" title="Bio">
        <VerifiedTag verified={p.verified} />
        <p className="sal-body-text" style={{ marginTop: 16, maxWidth: 520 }}>{p.bio}</p>
        <p className="sal-guide-pending sal-body-text" style={{ marginTop: 14, maxWidth: 520 }}>
          Retrato oficial, área de atuação, formação, registros profissionais e contexto de atuação serão informados pela própria equipe.
        </p>
        <button className="sal-cta-primary" style={{ marginTop: 24 }} onClick={onOpenJourney}>Começar sua jornada</button>
      </Section>
      {p.relatedEditorial && p.relatedEditorial.length > 0 && (
        <Section eyebrow="Conteúdo relacionado" title="Assinado por ela" tone="sienna">
          <div className="sal-related-row">
            {p.relatedEditorial.map((s) => {
              const a = PUBLISHED_EDITORIAL.find((x) => x.slug === s);
              if (!a) return null;
              return (
                <Link key={s} to={`/editorial/${s}`} className="sal-related-item">
                  <span className="sal-agora-type">{CONTENT_TYPE_LABELS[a.type]}</span>
                  <span className="salomao-serif">{a.title}</span>
                  <span className="sal-related-arrow">→</span>
                </Link>
              );
            })}
          </div>
        </Section>
      )}
    </>
  );
}

function EditorialPage() {
  return (
    <>
      <PageHero eyebrow="The Edit" title="Antes de escolher, entenda." support="Entender também faz parte do cuidado. Um espaço editorial para conhecer pele, estética e tratamentos com mais clareza." />
      <Section eyebrow="Entender antes de escolher" title="Leituras e conversas.">
        <div className="sal-editorial-row">
          {PUBLISHED_EDITORIAL.map((a) => {
            const i = EDITORIAL.findIndex((x) => x.slug === a.slug);
            const img = MEDIA.editorial[i % MEDIA.editorial.length];
            return (
              <Link key={a.slug} to={`/editorial/${a.slug}`} className="sal-editorial-card">
                <div className="sal-editorial-thumb">
                  <img className="sal-media-img" src={img.src} alt={img.alt} loading="lazy" />
                </div>
                <p className="sal-editorial-cat">{CONTENT_TYPE_LABELS[a.type]} · {a.category} · {a.readingTime}</p>
                <p className="salomao-serif sal-editorial-title">{a.title}</p>
                <VerifiedTag verified={a.verified} />
              </Link>
            );
          })}
        </div>
        <p className="sal-body-text" style={{ marginTop: 28, maxWidth: 480 }}>
          Em desenvolvimento: guias, explicações, conversas, eventos, aulas e novidades da clínica — cada formato entra quando houver conteúdo real da equipe.
        </p>
      </Section>
    </>
  );
}

function ArticleDetailPage({ slug }) {
  const a = PUBLISHED_EDITORIAL.find((x) => x.slug === slug);
  if (!a) return <NotFoundPage />;
  const idx = EDITORIAL.findIndex((x) => x.slug === slug);
  const img = MEDIA.editorial[idx % MEDIA.editorial.length];
  return (
    <>
      <PageHero eyebrow={`${CONTENT_TYPE_LABELS[a.type]} · ${a.category} · ${a.readingTime}`} title={a.title} />
      <div className="sal-fullbleed sal-fullbleed-short">
        <img className="sal-media-img" src={img.src} alt={img.alt} loading="lazy" />
      </div>
      <Section eyebrow="Entender antes de escolher" title="">
        <VerifiedTag verified={a.verified} />
        <p className="sal-body-text" style={{ marginTop: 16, maxWidth: 560 }}>{a.body}</p>
        {a.relatedTreatment && (() => {
          const t = TREATMENTS.find((x) => x.slug === a.relatedTreatment);
          if (!t) return null;
          return (
            <div style={{ marginTop: 28 }}>
              <Link to={`/tratamentos/${t.slug}`} className="sal-inline-link">Conhecer {t.name} →</Link>
            </div>
          );
        })()}
      </Section>
    </>
  );
}

function MySalomaoPage() {
  const features = [
    ["Sua jornada", "Um lugar para acompanhar seus próximos momentos, etapas e retornos."],
    ["Sua agenda", "Compromissos, retornos, eventos e lembretes reunidos em um só lugar."],
    ["Seus cuidados", "Conteúdos e recomendações relevantes para o seu momento."],
    ["Fale com a equipe", "Quando precisar, a Salomão a um toque."],
  ];
  return (
    <>
      <PageHero eyebrow="Conceito · em desenvolvimento" title="Sua jornada continua." support="Uma ideia de espaço pessoal para acompanhar o que vem depois." />
      <Section eyebrow="A ideia" title="O que estamos imaginando">
        <div className="sal-method-grid">
          {features.map(([w, d]) => (
            <div key={w} className="sal-method-item">
              <p className="salomao-serif sal-method-word" style={{ fontSize: 20 }}>{w}</p>
              <p className="sal-method-desc">{d}</p>
            </div>
          ))}
        </div>
      </Section>
      <Section eyebrow="Em desenvolvimento" title="My Salomão ainda está sendo preparado." dark>
        <p className="sal-body-text-light" style={{ maxWidth: 420 }}>
          Ainda não existe entrada nem cadastro. Enquanto isso, a equipe está a uma mensagem de distância.
        </p>
        <a href={waLink(WA_GENERAL)} target="_blank" rel="noreferrer" className="sal-inline-link" style={{ marginTop: 16, display: "inline-block" }}>
          Falar com a equipe →
        </a>
      </Section>
    </>
  );
}

function HoursBlock({ dark }) {
  return (
    <div className="sal-hours">
      {HOURS.map((h) => (
        <div key={h.day} className="sal-hours-row">
          <span className="sal-hours-day">{h.day}</span>
          <span className="sal-hours-time">{h.hours}</span>
        </div>
      ))}
    </div>
  );
}

function ContatoPage() {
  return (
    <>
      <PageHero eyebrow="Contato" title="Vamos conversar?" support="Escolha como prefere falar com a Salomão." />
      <Section eyebrow="WhatsApp" title="Fale agora" tone="sun">
        <p className="sal-body-text" style={{ marginBottom: 20, fontStyle: "italic" }}>
          "Olá, equipe Salomão! Estou pelo site e gostaria de falar com a equipe. Podem me orientar?"
        </p>
        <a href={waLink(WA_GENERAL)} target="_blank" rel="noreferrer" className="sal-cta-primary">Abrir WhatsApp</a>
      </Section>
      <Section eyebrow="Ligar" title={CONTACT.phoneDisplay} dark>
        <a href={CONTACT.telHref} className="sal-cta-primary">Ligar para a Salomão</a>
      </Section>
      <Section eyebrow="E-mail" title="Escreva para a gente">
        <a href={CONTACT.emailHref} className="sal-inline-link">{CONTACT.email}</a>
      </Section>
      <Section eyebrow="Instagram" title="Acompanhe a Salomão" dark>
        <a href={SOCIAL.instagram} target="_blank" rel="noreferrer" className="sal-inline-link">@esteticasalomao</a>
      </Section>
      <Section eyebrow="Horário" title="Quando estamos abertas">
        <HoursBlock />
      </Section>
      <Section eyebrow="A casa" title="Onde estamos" dark>
        <a href={MAPS_URL} target="_blank" rel="noreferrer" className="sal-address-link sal-body-text-light">
          {CONTACT.address1} · {CONTACT.address2}<br />{CONTACT.city} · {CONTACT.cep}
        </a>
        <a
          href={MAPS_URL}
          target="_blank"
          rel="noreferrer"
          className="sal-cta-secondary sal-cta-secondary-oncontrast"
          style={{ display: "inline-block", marginTop: 20 }}
        >
          Como chegar
        </a>
      </Section>
    </>
  );
}

function LegalPage({ eyebrow, title, sections }) {
  return (
    <>
      <PageHero eyebrow={eyebrow} title={title} support="Última atualização: em preparação." />
      <Section eyebrow="Documento" title="">
        {sections.map(([heading, body]) => (
          <div key={heading} className="sal-legal-block">
            <p className="salomao-serif sal-legal-heading">{heading}</p>
            <p className="sal-body-text">{body}</p>
          </div>
        ))}
      </Section>
    </>
  );
}

function PrivacidadePage() {
  return <LegalPage eyebrow="Legal" title="Política de Privacidade" sections={PRIVACY_SECTIONS} />;
}

function TermosPage() {
  return <LegalPage eyebrow="Legal" title="Termos de Uso" sections={TERMS_SECTIONS} />;
}

function NotFoundPage() {
  return (
    <PageHero eyebrow="404" title="Página não encontrada" support="Esse endereço não existe no site da Salomão." />
  );
}

/* ---------------- APP ROOT ---------------- */

function AppShell() {
  const { path } = useRouter();
  const route = matchRoute(path);
  const [journeyOpen, setJourneyOpen] = useState(false);
  const [journeyGoal, setJourneyGoal] = useState(null);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setLoaded(true), 80);
    return () => clearTimeout(t);
  }, []);

  const openJourney = () => { setJourneyGoal(null); setJourneyOpen(true); };
  const openJourneyFor = (goal) => { setJourneyGoal(goal); setJourneyOpen(true); };

  let page;
  switch (route.name) {
    case "home": page = <HomePage onOpenJourney={openJourney} onOpenJourneyFor={openJourneyFor} />; break;
    case "clinica": page = <ClinicaPage />; break;
    case "metodo": page = <MetodoPage />; break;
    case "tratamentos": page = <TratamentosPage onOpenJourneyFor={openJourneyFor} />; break;
    case "treatment": page = <TreatmentDetailPage slug={route.slug} onOpenJourneyFor={openJourneyFor} />; break;
    case "resultados": page = <ResultadosPage />; break;
    case "result": page = <ResultDetailPage slug={route.slug} />; break;
    case "equipe": page = <EquipePage />; break;
    case "team-member": page = <TeamDetailPage slug={route.slug} onOpenJourney={openJourney} />; break;
    case "editorial": page = <EditorialPage />; break;
    case "article": page = <ArticleDetailPage slug={route.slug} />; break;
    case "my-salomao": page = <MySalomaoPage />; break;
    case "contato": page = <ContatoPage />; break;
    case "privacidade": page = <PrivacidadePage />; break;
    case "termos": page = <TermosPage />; break;
    default: page = <NotFoundPage />;
  }

  return (
    <div className={`salomao-root ${loaded ? "is-loaded" : ""}`}>
      <GlobalStyle />
      <Header onOpenJourney={openJourney} />
      <main key={path} className="sal-page-transition">{page}</main>
      <Footer />
      <JourneyModal open={journeyOpen} onClose={() => setJourneyOpen(false)} initialTreatment={journeyGoal} />
    </div>
  );
}

export default function SalomaoSite() {
  return (
    <RouterProvider>
      <AppShell />
    </RouterProvider>
  );
}

/* ---------------- STYLES ---------------- */

function GlobalStyle() {
  return (
    <style>{`
      @import url('https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,340;0,9..144,440;0,9..144,560;1,9..144,440&family=Archivo:wght@400;500;600&display=swap');

      .salomao-root {
        --ink: #171513;
        --ink-soft: #241E17;
        --porcelain: #F8F5EF;
        --sand: #D9CBBE;
        --gold: #B89A68;
        --gold-soft: #D9BD8E;
        --sun: #F5A623;
        --amber: #D9822B;
        --sienna: #8B4F3B;
        --blush: #D98B83;
        --ember: #D9822B;
        --espresso: #45352C;
        /* Spacing system — every section/element-relationship rule below should
           reference one of these rather than a one-off pixel value. Values use
           clamp() where the gap should scale with viewport rather than jump at
           a breakpoint. */
        --space-1: 4px;
        --space-2: 8px;
        --space-3: 12px;
        --space-4: 16px;
        --space-5: 24px;
        --space-6: 32px;
        --space-7: 48px;
        --space-8: 64px;
        --space-9: 80px;
        --space-10: 96px;
        --space-11: clamp(96px, 10vw, 120px);
        --space-12: clamp(120px, 13vw, 160px);
        --container-padding: clamp(20px, 4vw, 64px);
        font-family: 'Archivo', sans-serif;
        background: var(--ink);
        color: var(--porcelain);
        min-height: 100vh;
        position: relative;
        overflow-x: hidden;
      }
      .salomao-serif { font-family: 'Fraunces', serif; }

      a { color: inherit; }
      button { font-family: inherit; }

      .sal-page-transition {
        animation: sal-page-in 0.4s ease both;
      }
      @keyframes sal-page-in {
        from { opacity: 0; transform: translateY(10px); }
        to { opacity: 1; transform: translateY(0); }
      }

      /* Header */
      .sal-header {
        position: sticky; top: 0; z-index: 30;
        display: flex; align-items: center; justify-content: space-between;
        padding: 22px var(--container-padding);
        background: rgba(23,21,19,0.86);
        backdrop-filter: blur(10px);
        border-bottom: 1px solid rgba(255,255,255,0.06);
        transition: padding 0.35s ease, background 0.35s ease;
      }
      .sal-header.is-scrolled {
        padding-top: 13px; padding-bottom: 13px;
        background: rgba(23,21,19,0.96);
      }
      .sal-mark {
        font-family: 'Fraunces', serif; font-weight: 560; font-size: 18px;
        letter-spacing: 0.14em; color: var(--porcelain); text-decoration: none;
      }
      .sal-nav { display: none; align-items: center; gap: 26px; }
      @media (min-width: 980px) { .sal-nav { display: flex; } .sal-nav-toggle { display: none; } }
      .sal-nav a {
        font-size: 12px; letter-spacing: 0.07em; text-transform: uppercase;
        color: var(--sand); text-decoration: none; padding-bottom: 3px;
        border-bottom: 1px solid transparent; transition: color 0.25s ease, border-color 0.25s ease;
      }
      .sal-nav a:hover, .sal-nav a.is-active { color: var(--porcelain); border-color: var(--gold); }
      .sal-header-right { display: flex; align-items: center; gap: 14px; }
      .sal-my { font-size: 11.5px; letter-spacing: 0.07em; color: var(--gold-soft); text-decoration: none; white-space: nowrap; }
      .sal-nav-toggle {
        background: none; border: 1px solid var(--espresso); color: var(--porcelain);
        width: 36px; height: 36px; border-radius: 50%; cursor: pointer;
        display: flex; align-items: center; justify-content: center;
        transition: border-color 0.25s ease;
      }
      .sal-nav-toggle:hover { border-color: var(--gold); }
      .sal-nav-toggle-icon { position: relative; width: 15px; height: 10px; display: block; }
      .sal-nav-toggle-icon span {
        position: absolute; left: 0; width: 100%; height: 1px; background: var(--porcelain);
        transition: transform 0.3s ease, top 0.3s ease, opacity 0.2s ease;
      }
      .sal-nav-toggle-icon span:first-child { top: 0; }
      .sal-nav-toggle-icon span:last-child { top: 9px; }
      .sal-nav-toggle-icon.is-open span:first-child { top: 4px; transform: rotate(45deg); }
      .sal-nav-toggle-icon.is-open span:last-child { top: 4px; transform: rotate(-45deg); }

      /* Drawer */
      .sal-drawer {
        position: fixed; inset: 0; z-index: 60; background: var(--ink);
        display: flex; flex-direction: column; padding: 26px var(--container-padding);
      }
      .sal-drawer-head { display: flex; align-items: center; justify-content: space-between; }
      .sal-drawer-close { background: none; border: none; color: var(--porcelain); font-size: 28px; cursor: pointer; }
      .sal-drawer-nav { display: flex; flex-direction: column; gap: 18px; margin-top: 48px; overflow-y: auto; }
      .sal-drawer-nav a {
        font-family: 'Fraunces', serif; font-size: 26px; color: var(--porcelain);
        text-decoration: none; border-bottom: 1px solid var(--ink-soft); padding-bottom: 12px;
      }
      .sal-drawer-cta { margin-top: 24px; width: 100%; padding: 16px; }

      /* quick contact */
      .sal-quickcontact { position: fixed; right: 20px; bottom: 20px; z-index: 40; }
      .sal-quickcontact-btn {
        display: flex; align-items: center; gap: 9px;
        background: var(--ink); color: var(--porcelain);
        border: 1px solid rgba(217,189,142,0.35);
        border-radius: 999px;
        padding: 13px 20px 13px 16px; font-size: 12px; letter-spacing: 0.04em; cursor: pointer;
        box-shadow: 0 10px 28px rgba(0,0,0,0.28);
        transition: background 0.3s ease, transform 0.2s ease, border-color 0.3s ease, padding 0.2s ease;
      }
      /* Below 480px the pill collapses to an icon-only circle — the full-text
         version was colliding with primary CTAs sitting at common mobile
         scroll-rest positions (found via actual screenshot QA, not guessed). */
      @media (max-width: 480px) {
        .sal-quickcontact { right: 16px; bottom: 16px; }
        .sal-quickcontact-btn {
          padding: 0; width: 44px; height: 44px; justify-content: center;
        }
        .sal-quickcontact-label { display: none; }
        .sal-quickcontact-dot { width: 8px; height: 8px; }
      }
      .sal-quickcontact-btn:hover { border-color: var(--gold); transform: translateY(-1px); }
      .sal-quickcontact-btn:active { transform: scale(0.97); }
      .sal-quickcontact-dot { width: 6px; height: 6px; border-radius: 50%; background: var(--gold); flex-shrink: 0; }
      .sal-quickcontact.is-open .sal-quickcontact-btn { border-color: var(--gold); }
      .sal-phone-popover {
        position: absolute; bottom: 60px; right: 0; background: var(--porcelain); border-radius: 8px;
        overflow: hidden; display: flex; flex-direction: column; min-width: 190px;
        box-shadow: 0 16px 40px rgba(0,0,0,0.35);
        animation: sal-popover-in 0.25s cubic-bezier(0.16,1,0.3,1) both;
      }
      @keyframes sal-popover-in {
        from { opacity: 0; transform: translateY(8px); }
        to { opacity: 1; transform: translateY(0); }
      }
      .sal-phone-popover a {
        display: flex; flex-direction: column; gap: 2px;
        padding: 13px 18px; text-decoration: none; color: var(--ink);
        border-bottom: 1px solid var(--sand); transition: background 0.2s ease;
      }
      .sal-phone-popover a:hover { background: rgba(184,154,104,0.12); }
      .sal-phone-popover a:last-child { border-bottom: none; }
      .sal-phone-popover a span { font-size: 13px; font-weight: 500; }
      .sal-phone-popover a em { font-size: 11px; font-style: normal; color: var(--espresso); opacity: 0.65; }

      /* Hero (home) */
      .sal-hero {
        position: relative; min-height: 92vh; display: flex; align-items: flex-end;
        overflow: hidden; padding: 0 var(--container-padding) 64px;
      }
      .sal-hero-cinematic { padding-top: 0; }
      .sal-hero-bgvideo { z-index: 0; }
      .sal-hero-brightness-scrim {
        position: absolute; inset: 0; z-index: 1; background: var(--ink); pointer-events: none;
        transition: opacity 0.1s linear;
      }
      .sal-hero-text { position: relative; z-index: 20; padding-top: clamp(40px, 8vh, 90px); max-width: 640px; }

      /* Belief section — cinematic full-bleed video moment */
      .sal-belief-cinematic {
        position: relative; min-height: 72vh; display: flex; align-items: center;
        overflow: hidden; padding: var(--space-8) var(--container-padding);
        clip-path: inset(7% 7% 7% 7%);
        opacity: 0;
        transition: clip-path 1.1s cubic-bezier(0.16,1,0.3,1), opacity 0.8s ease;
      }
      .sal-belief-cinematic.is-revealed { clip-path: inset(0 0 0 0); opacity: 1; }
      @media (prefers-reduced-motion: reduce) {
        .sal-belief-cinematic { clip-path: inset(0 0 0 0); opacity: 1; transition: none; }
      }
      .sal-belief-content { position: relative; z-index: 2; max-width: 460px; }
      .sal-belief-title { font-size: clamp(32px, 5vw, 54px); font-weight: 440; margin: 0 0 20px; color: var(--porcelain); }

      .sal-eyebrow-rule { display: flex; align-items: center; gap: var(--space-3); margin-bottom: var(--space-5); }
      .sal-eyebrow-rule span { display: inline-block; width: 30px; height: 1px; background: var(--gold); }
      .sal-eyebrow-rule p { font-size: 12px; letter-spacing: 0.06em; color: var(--gold-soft); margin: 0; }
      /* contrast fix: gold-soft is unreadable on light porcelain backgrounds — use a deeper gold there.
         .sal-page-hero is always dark, so it's excluded and keeps gold-soft. */
      .sal-section:not(.sal-section-dark) .sal-eyebrow-rule p { color: #8C6A3D; }

      .sal-headline {
        font-family: 'Fraunces', serif; font-weight: 440; font-size: clamp(52px, 9vw, 112px);
        line-height: 0.94; margin: 0 0 24px; letter-spacing: -0.01em; color: var(--porcelain);
      }
      .sal-headline .line { display: block; overflow: hidden; }
      .sal-headline .line span { display: block; transform: translateY(105%); transition: transform 1.05s cubic-bezier(0.16,1,0.3,1); }
      .salomao-root.is-loaded .sal-headline .line:nth-child(1) span { transform: translateY(0); transition-delay: 0.2s; }
      .salomao-root.is-loaded .sal-headline .line:nth-child(2) span { transform: translateY(0); transition-delay: 0.32s; }
      .sal-headline .accent { font-style: italic; color: var(--ember); }

      .sal-support { font-size: clamp(14px,1.5vw,17px); color: var(--sand); max-width: 340px; margin: 0 0 36px; }
      .sal-cta-row { display: flex; align-items: center; gap: 24px; flex-wrap: wrap; }

      .sal-cta-primary {
        font-size: 13px; letter-spacing: 0.05em; text-transform: uppercase; color: var(--ink);
        background: var(--porcelain); border: none; padding: 15px 28px; border-radius: 2px; cursor: pointer;
        text-decoration: none; display: inline-block; transition: background 0.3s ease, transform 0.2s ease;
      }
      .sal-cta-primary:hover { background: var(--gold-soft); transform: translateY(-1px); }
      .sal-cta-primary:active { transform: scale(0.98); }

      .sal-cta-secondary {
        font-size: 13px; color: var(--sand); background: none; border: none; text-decoration: none;
        border-bottom: 1px solid var(--espresso); padding-bottom: 3px; cursor: pointer;
        transition: color 0.3s ease, border-color 0.3s ease;
      }
      .sal-cta-secondary:hover { color: var(--porcelain); border-color: var(--gold); }
      .sal-cta-secondary-oncontrast { color: var(--porcelain); border-bottom-color: rgba(247,242,234,0.5); }
      .sal-cta-secondary-oncontrast:hover { color: var(--gold-soft); border-color: var(--gold); }
      /* contrast fix: sal-cta-secondary defaults to light text (correct on dark/ink contexts),
         but on light/sun/blush section backgrounds it needs dark ink text instead */
      .sal-section:not(.sal-section-dark):not(.sal-section-sienna) .sal-cta-secondary {
        color: var(--ink); border-bottom-color: var(--gold);
      }
      .sal-section:not(.sal-section-dark):not(.sal-section-sienna) .sal-cta-secondary:hover {
        color: var(--sienna); border-color: var(--sienna);
      }

      /* shared frame treatment for real photography — object-fit cover, consistent radius */
      .sal-team-photo, .sal-archive-image,
      .sal-team-featured-photo, .sal-magazine-feature-photo, .sal-explorer-swatch {
        position: relative; overflow: hidden;
      }
      .sal-media-img { width: 100%; height: 100%; object-fit: cover; display: block; }
      .sal-fullbleed { position: relative; width: 100%; height: clamp(320px, 52vh, 560px); overflow: hidden; }

      /* Background video system */
      .sal-bgvideo { position: absolute; inset: 0; overflow: hidden; }
      .sal-bgvideo-media {
        width: 100%; height: 100%; object-fit: cover;
        object-position: var(--sal-objpos-mobile);
        display: block;
      }
      @media (min-width: 860px) {
        .sal-bgvideo-media { object-position: var(--sal-objpos-desktop); }
      }
      .sal-bgvideo-overlay {
        position: absolute; inset: 0;
        background: linear-gradient(180deg, rgba(23,21,19,0.55) 0%, rgba(23,21,19,0.25) 40%, rgba(23,21,19,0.7) 100%);
      }
      .sal-fullbleed-short { height: clamp(240px, 38vh, 400px); }
      .sal-fullbleed-caption {
        position: absolute; left: var(--container-padding); bottom: 20px; z-index: 1;
        font-size: 10.5px; letter-spacing: 0.05em; color: var(--porcelain);
        background: rgba(23,21,19,0.55); backdrop-filter: blur(4px);
        padding: 6px 12px; border-radius: 999px;
      }

      /* Generic sections */
      .sal-section { padding: var(--space-11) var(--container-padding); background: var(--porcelain); color: var(--ink); }
      /* Deliberate rhythm variation — not every section is the same height.
         "quiet" is a short breathing beat; "major" is a slower, weightier pause. */
      .sal-section-quiet { padding-top: var(--space-9); padding-bottom: var(--space-9); }
      .sal-section-major { padding-top: var(--space-12); padding-bottom: var(--space-12); }

      /* A deliberately quiet pause — no image, no interaction, just a breath
         between two dense browsing moments (Treatments and Results). */
      .sal-quiet-statement {
        background: var(--ink); color: var(--porcelain);
        padding: var(--space-8) var(--container-padding);
        text-align: center;
      }
      .sal-quiet-statement-text {
        font-size: clamp(20px, 3vw, 28px); font-style: italic;
        max-width: 560px; margin: 0 auto var(--space-3);
      }
      .sal-quiet-statement-note {
        font-size: 12px; color: var(--sand); opacity: 0.7; margin: 0;
      }
      .sal-section-dark { background: var(--ink); color: var(--porcelain); }
      .sal-section-sun { background: var(--sun); color: var(--ink); }
      .sal-section-blush { background: var(--blush); color: var(--espresso); }
      .sal-section-sienna { background: var(--sienna); color: var(--porcelain); }
      .sal-section-center { text-align: center; }

      .sal-reveal-pre { opacity: 0; transform: translateY(28px); }
      .sal-reveal-in { opacity: 1; transform: translateY(0); transition: opacity 0.9s cubic-bezier(0.16,1,0.3,1), transform 0.9s cubic-bezier(0.16,1,0.3,1); }
      @media (prefers-reduced-motion: reduce) {
        .sal-reveal-pre { opacity: 1; transform: none; }
      }

      /* My Salomão — product reveal */
      /* Salomão Agora — compact living-content strip, real published items only */
      .sal-agora {
        background: var(--sienna); color: var(--porcelain);
        padding: var(--space-9) var(--container-padding);
      }
      .sal-agora-lead { font-size: clamp(22px, 2.8vw, 30px); margin: 0 0 var(--space-6); max-width: 480px; }
      .sal-agora-row { display: flex; flex-direction: column; border-top: 1px solid rgba(247,242,234,0.18); }
      @media (min-width: 780px) { .sal-agora-row { flex-direction: row; } }
      .sal-agora-item {
        display: flex; align-items: center; gap: var(--space-3);
        padding: var(--space-5) 0; text-decoration: none; color: inherit;
        border-bottom: 1px solid rgba(247,242,234,0.18);
        flex: 1;
      }
      @media (min-width: 780px) {
        .sal-agora-item { padding: var(--space-5) var(--space-5) var(--space-5) 0; border-bottom: none; border-right: 1px solid rgba(247,242,234,0.18); }
        .sal-agora-item:last-child { border-right: none; }
      }
      .sal-agora-type {
        font-size: 10.5px; letter-spacing: 0.06em; text-transform: uppercase;
        color: var(--gold-soft); border: 1px solid rgba(217,189,142,0.4);
        padding: 3px 9px; border-radius: 999px; flex-shrink: 0;
      }
      .sal-agora-title { font-size: 16px; flex: 1; }
      .sal-agora-arrow { opacity: 0; transform: translateX(-4px); transition: opacity 0.25s ease, transform 0.25s ease; }
      .sal-agora-item:hover .sal-agora-arrow { opacity: 1; transform: translateX(0); }
      .sal-agora-item:hover .sal-agora-title { text-decoration: underline; text-decoration-color: var(--gold); }

      /* Related-content links — the "web of discovery" connecting treatments,
         editorial content and team profiles. Deliberately soft (inline-link
         style, not another primary CTA) so it invites exploration rather than
         another conversion push. */
      .sal-related-row { display: flex; flex-direction: column; gap: 4px; max-width: 480px; }
      .sal-related-item {
        display: flex; align-items: center; gap: var(--space-3);
        padding: var(--space-4) 0; text-decoration: none; color: inherit;
        border-bottom: 1px solid rgba(247,242,234,0.15);
      }
      .sal-related-item span:nth-child(2) { flex: 1; font-size: 16px; }
      .sal-related-arrow { opacity: 0; transform: translateX(-4px); transition: opacity 0.25s ease, transform 0.25s ease; }
      .sal-related-item:hover .sal-related-arrow { opacity: 1; transform: translateX(0); }
      .sal-related-item:hover span:nth-child(2) { text-decoration: underline; text-decoration-color: var(--gold); }

      .sal-product-reveal {
        display: grid; grid-template-columns: 1fr; gap: 48px; align-items: center;
      }
      @media (min-width: 900px) { .sal-product-reveal { grid-template-columns: 1.1fr 0.9fr; } }
      .sal-phone-mock { display: flex; justify-content: center; }
      .sal-phone-mock-frame {
        width: 240px; border-radius: 28px; background: var(--ink-soft);
        border: 1px solid rgba(217,189,142,0.25); padding: 20px 18px;
        box-shadow: 0 30px 60px rgba(0,0,0,0.45);
      }
      .sal-phone-mock-notch { width: 50px; height: 5px; border-radius: 3px; background: rgba(247,242,234,0.15); margin: 0 auto 22px; }
      .sal-phone-mock-heading { font-family: 'Fraunces', serif; font-size: 19px; color: var(--porcelain); margin: 0 0 16px; }
      .sal-phone-mock-row {
        display: flex; align-items: center; gap: 10px; padding: 12px 0;
        border-top: 1px solid rgba(247,242,234,0.08);
        font-size: 12px; color: var(--sand);
        opacity: 0; transform: translateX(10px);
        transition: opacity 0.6s ease, transform 0.6s ease;
      }
      .sal-phone-mock-row.is-in { opacity: 1; transform: translateX(0); }
      .sal-phone-mock-dot { width: 5px; height: 5px; border-radius: 50%; background: var(--gold); flex-shrink: 0; }

      /* Treatment explorer */
      .sal-explorer { display: grid; grid-template-columns: 1fr; gap: 8px; }
      @media (min-width: 860px) { .sal-explorer { grid-template-columns: 1fr 1fr; gap: 40px; align-items: start; } }
      .sal-explorer-list { display: flex; flex-direction: column; }
      .sal-explorer-item {
        display: flex; align-items: center; justify-content: space-between;
        background: none; border: none; border-bottom: 1px solid rgba(58,46,36,0.18);
        padding: 18px 4px; cursor: pointer; text-align: left; color: inherit;
      }
      .sal-explorer-item-name { font-size: clamp(20px, 2.6vw, 28px); transition: color 0.25s ease, transform 0.25s ease; }
      .sal-explorer-item-arrow { opacity: 0; transform: translateX(-6px); transition: opacity 0.25s ease, transform 0.25s ease; color: var(--espresso); }
      .sal-explorer-item.is-active .sal-explorer-item-name { transform: translateX(6px); }
      .sal-explorer-item.is-active .sal-explorer-item-arrow { opacity: 1; transform: translateX(0); }
      .sal-explorer-item.is-active { border-color: var(--espresso); }
      .sal-explorer-preview { padding-top: 4px; }
      .sal-explorer-swatch {
        width: 100%; aspect-ratio: 16/10; border-radius: 2px; margin-bottom: 18px;
        position: relative; overflow: hidden;
      }
      .sal-explorer-img { animation: sal-crossfade 0.5s ease both; }
      @keyframes sal-crossfade { from { opacity: 0; transform: scale(1.03); } to { opacity: 1; transform: scale(1); } }
      .sal-explorer-swatch-label {
        position: absolute; left: 16px; bottom: 14px; z-index: 1;
        font-family: 'Fraunces', serif; font-style: italic; font-size: 34px; color: var(--porcelain);
        text-shadow: 0 2px 12px rgba(0,0,0,0.5);
      }
      .sal-explorer-short { font-size: 14.5px; line-height: 1.6; color: var(--espresso); margin-bottom: 10px; max-width: 380px; }

      /* Treatment explorer — mobile/tablet accordion (desktop uses .sal-explorer above) */
      .sal-explorer-accordion { display: block; }
      .sal-accordion-item { border-bottom: 1px solid rgba(58,46,36,0.15); }
      .sal-accordion-trigger {
        width: 100%; display: flex; align-items: center; justify-content: space-between;
        background: none; border: none; padding: 20px 4px; cursor: pointer; text-align: left;
        color: inherit; min-height: 56px;
      }
      .sal-accordion-chevron { display: inline-block; transition: transform 0.3s ease; color: var(--espresso); }
      .sal-accordion-chevron.is-open { transform: rotate(90deg); }
      .sal-accordion-panel {
        display: grid; grid-template-rows: 0fr;
        transition: grid-template-rows 0.45s cubic-bezier(0.16,1,0.3,1);
      }
      .sal-accordion-panel.is-open { grid-template-rows: 1fr; }
      .sal-accordion-panel-inner {
        overflow: hidden; min-height: 0; opacity: 0; transition: opacity 0.3s ease;
        padding-bottom: 4px;
      }
      .sal-accordion-panel.is-open .sal-accordion-panel-inner { opacity: 1; transition-delay: 0.12s; }
      .sal-accordion-activeline { height: 2px; width: 48px; background: var(--sienna); margin-top: 18px; }

      /* Team — featured + list, not equal cards */
      .sal-team-featured { display: grid; grid-template-columns: 1fr; gap: 28px; margin-bottom: 24px; }
      @media (min-width: 860px) { .sal-team-featured { grid-template-columns: 1.1fr 0.9fr; } }
      .sal-team-featured-main { text-decoration: none; color: inherit; display: block; }
      .sal-team-featured-photo {
        width: 100%; aspect-ratio: 4/5; background: var(--ink-soft);
        border-radius: 2px; margin-bottom: 16px; position: relative; overflow: hidden;
      }
      .sal-team-photo-caption {
        position: absolute; left: 12px; bottom: 12px; z-index: 1;
        font-size: 10px; letter-spacing: 0.04em; color: var(--porcelain);
        background: rgba(23,21,19,0.6); backdrop-filter: blur(3px);
        padding: 5px 10px; border-radius: 999px; max-width: calc(100% - 24px);
      }
      .sal-team-featured-name { font-size: clamp(24px, 3vw, 34px); margin: 0 0 6px; }
      .sal-team-featured-list { display: flex; flex-direction: column; justify-content: center; gap: 0; }
      .sal-team-featured-item {
        display: flex; flex-direction: column; gap: 4px; text-decoration: none; color: inherit;
        padding: 20px 0; border-bottom: 1px solid rgba(247,242,234,0.15);
      }
      .sal-section:not(.sal-section-dark):not(.sal-section-sienna) .sal-team-featured-item { border-bottom-color: rgba(58,46,36,0.15); }
      .sal-team-featured-item span:first-child { font-size: 20px; }

      /* The Edit — magazine: one feature + supporting list */
      .sal-magazine { display: grid; grid-template-columns: 1fr; gap: 32px; margin-bottom: 24px; }
      @media (min-width: 860px) { .sal-magazine { grid-template-columns: 1.3fr 0.7fr; } }
      .sal-magazine-feature { text-decoration: none; color: inherit; display: block; }
      .sal-magazine-feature-photo {
        width: 100%; aspect-ratio: 16/10; background: #EFE8DC; border: 1px dashed rgba(58,46,36,0.3);
        border-radius: 2px; margin-bottom: 16px;
      }
      .sal-magazine-feature-title { font-size: clamp(24px, 3.4vw, 36px); margin: 6px 0 0; }
      .sal-magazine-side { display: flex; flex-direction: column; }
      .sal-magazine-side-item {
        text-decoration: none; color: inherit; padding: 20px 0; border-top: 1px solid rgba(58,46,36,0.15);
      }
      .sal-magazine-side-item:last-child { border-bottom: 1px solid rgba(58,46,36,0.15); }
      .sal-magazine-side-item p:last-child { font-size: 18px; margin: 6px 0 0; }

      /* Results archive — browse cases, not a static grid */
      .sal-archive-main {
        position: relative; overflow: hidden; border-radius: 2px;
        min-height: clamp(420px, 62vh, 640px); margin-bottom: 24px;
        transition: opacity 0.16s ease;
      }
      .sal-archive-main.is-out { opacity: 0; }
      .sal-archive-main.is-in { opacity: 1; }
      .sal-archive-image { position: absolute; inset: 0; }
      .sal-archive-scrim {
        position: absolute; inset: 0;
        background: linear-gradient(0deg, rgba(23,21,19,0.92) 0%, rgba(23,21,19,0.55) 32%, transparent 62%);
      }
      .sal-archive-info { position: absolute; left: 0; right: 0; bottom: 0; padding: clamp(24px, 4vw, 48px); max-width: 480px; }
      .sal-archive-case { font-size: 11px; letter-spacing: 0.08em; color: var(--gold-soft); margin: 0 0 10px; }
      .sal-archive-title { font-size: clamp(26px, 4vw, 42px); margin: 0 0 8px; color: var(--porcelain); }
      .sal-archive-treatment { font-size: 13.5px; color: var(--sand); margin: 0 0 12px; }
      .sal-archive-link { text-shadow: 0 1px 8px rgba(0,0,0,0.4); }
      .sal-archive-tabs { display: flex; gap: 8px; flex-wrap: wrap; }
      .sal-archive-tab {
        width: 36px; height: 36px; border-radius: 50%; border: 1px solid rgba(247,242,234,0.25);
        background: none; color: var(--sand); font-size: 12px; cursor: pointer;
        transition: border-color 0.25s ease, color 0.25s ease, background 0.25s ease;
      }
      .sal-archive-tab:hover { border-color: var(--gold); color: var(--porcelain); }
      .sal-archive-tab.is-active { background: var(--gold); border-color: var(--gold); color: var(--ink); }
      .sal-section-title { font-size: clamp(32px, 4.5vw, 54px); font-weight: 440; letter-spacing: -0.01em; margin: 0 0 var(--space-6); max-width: 640px; }
      .sal-body-text { font-size: 15.5px; line-height: 1.7; color: var(--espresso); max-width: 560px; }
      .sal-body-text-light { font-size: 15.5px; line-height: 1.7; color: var(--sand); max-width: 560px; }
      /* tone-aware overrides: text color follows the section's actual background, regardless of which
         text class a page happens to use — prevents low-contrast mismatches across color chapters */
      .sal-section-dark .sal-body-text, .sal-section-sienna .sal-body-text { color: var(--sand); }
      .sal-section-sun .sal-body-text-light, .sal-section-blush .sal-body-text-light { color: var(--espresso); }
      .sal-section-sienna .sal-body-text-light { color: var(--sand); }
      .sal-section-dark .sal-eyebrow-rule p { color: var(--gold-soft); }
      .sal-section-sienna .sal-eyebrow-rule p { color: var(--porcelain); }
      .sal-section-sun .sal-eyebrow-rule p, .sal-section-blush .sal-eyebrow-rule p { color: var(--ink); opacity: 1; font-weight: 600; }
      .sal-section-sun .sal-eyebrow-rule span, .sal-section-blush .sal-eyebrow-rule span { background: var(--ink); opacity: 0.55; }

      .sal-page-hero { padding: var(--space-11) var(--container-padding) var(--space-8); background: var(--ink); color: var(--porcelain); }
      .sal-back-link {
        display: inline-flex; align-items: center; gap: 8px; background: none; border: none;
        color: var(--sand); font-size: 13px; letter-spacing: 0.02em; cursor: pointer;
        padding: 10px 4px; margin: -10px 0 22px -4px; min-height: 40px;
        transition: color 0.25s ease;
      }
      .sal-back-link:hover { color: var(--porcelain); }
      .sal-back-link:focus-visible { outline: 1px solid var(--gold); outline-offset: 4px; }
      .sal-back-arrow { display: inline-block; transition: transform 0.25s ease; }
      .sal-back-link:hover .sal-back-arrow { transform: translateX(-4px); }
      .sal-page-title { font-size: clamp(40px, 6vw, 76px); font-weight: 440; margin: 8px 0 16px; }
      .sal-page-support { color: var(--sand); max-width: 480px; font-size: 15px; }

      .sal-method-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 32px; max-width: 640px; margin-bottom: 24px; }
      @media (min-width: 780px) { .sal-method-grid { grid-template-columns: repeat(4, 1fr); } }

      /* Método page — staggered sequence, replacing the old four-equal-columns treatment */
      .sal-method-sequence {
        position: relative;
        background: var(--porcelain);
        color: var(--ink);
        padding: 90px var(--container-padding) 110px;
        overflow: hidden;
      }
      .sal-method-seq-line {
        position: absolute;
        left: var(--container-padding);
        top: 90px;
        bottom: 110px;
        width: 1px;
        background: var(--sand);
        opacity: 0.6;
      }
      .sal-method-seq-line-fill {
        position: absolute;
        left: var(--container-padding);
        top: 90px;
        width: 2px;
        background: linear-gradient(to bottom, var(--gold), var(--sienna));
        transition: height 0.7s cubic-bezier(0.16,1,0.3,1);
        box-shadow: 0 0 12px rgba(184,154,104,0.5);
      }
      .sal-method-seq-item {
        position: relative;
        max-width: 480px;
        padding: 46px 0;
        border-bottom: 1px solid var(--sand);
        opacity: 0.35;
        transform: translateX(-12px);
        transition: opacity 0.6s cubic-bezier(0.16,1,0.3,1), transform 0.6s cubic-bezier(0.16,1,0.3,1);
      }
      .sal-method-seq-item.is-revealed { opacity: 1; transform: translateX(0); }
      .sal-method-seq-item:last-child { border-bottom: none; }
      .sal-method-seq-index {
        display: block;
        font-size: 13px;
        letter-spacing: 0.08em;
        color: #8C6A3D;
        margin-bottom: 10px;
      }
      .sal-method-seq-word {
        font-size: clamp(34px, 5vw, 56px);
        margin: 0 0 14px;
        font-weight: 440;
      }
      .sal-method-seq-desc {
        font-size: 15px;
        color: var(--espresso);
        line-height: 1.6;
        max-width: 400px;
      }
      .sal-method-word { font-size: 26px; margin: 0 0 10px; }
      .sal-method-desc { font-size: 13.5px; color: var(--sand); line-height: 1.5; }
      .sal-section:not(.sal-section-dark) .sal-method-desc { color: var(--espresso); }

      .sal-goal-row { display: flex; flex-wrap: wrap; gap: 12px; }
      .sal-option {
        border: 1px solid var(--espresso); background: none; color: var(--ink);
        padding: 12px 18px; border-radius: 999px; font-size: 13px; cursor: pointer;
        transition: background 0.25s ease, color 0.25s ease, border-color 0.25s ease, transform 0.15s ease;
      }
      .sal-section-dark .sal-option { color: var(--porcelain); border-color: rgba(255,255,255,0.25); }
      .sal-option:hover { background: var(--ink); color: var(--porcelain); border-color: var(--ink); }
      .sal-section-dark .sal-option:hover { background: var(--porcelain); color: var(--ink); }
      .sal-option:active { transform: scale(0.96); }
      .sal-option.is-selected {
        background: var(--gold); color: var(--ink); border-color: var(--gold);
        transform: scale(1.04); transition: background 0.2s ease, transform 0.2s cubic-bezier(0.34,1.56,0.64,1);
      }

      .sal-treatment-grid { display: grid; grid-template-columns: 1fr; gap: 1px; background: var(--sand); margin-bottom: 20px; }
      @media (min-width: 780px) { .sal-treatment-grid { grid-template-columns: repeat(2, 1fr); } }
      .sal-treatment-card {
        background: var(--porcelain); padding: 28px; text-decoration: none; color: var(--ink);
        position: relative; transition: background 0.25s ease;
      }
      .sal-treatment-card:hover { background: #EFE6D6; }
      .sal-treatment-name { font-size: 21px; margin: 0 0 8px; }
      .sal-treatment-short { font-size: 13px; color: var(--espresso); margin: 0 0 8px; }
      .sal-card-arrow { position: absolute; right: 24px; top: 24px; transition: transform 0.25s ease; }
      .sal-treatment-card:hover .sal-card-arrow { transform: translateX(4px); }

      .sal-team-row, .sal-editorial-row { display: flex; gap: 20px; flex-wrap: wrap; margin-bottom: 20px; }
      .sal-team-card, .sal-editorial-card {
        text-decoration: none; color: inherit; width: 220px; display: block;
      }
      .sal-team-photo {
        width: 100%; aspect-ratio: 3/4; border-radius: 2px; margin-bottom: 12px;
        background: var(--ink-soft);
        position: relative; overflow: hidden;
      }
      .sal-team-card p:first-of-type { font-size: 14px; margin: 8px 0; }
      .sal-team-role { font-size: 12px; color: var(--espresso); }
      .sal-section-dark .sal-team-role, .sal-section-sienna .sal-team-role { color: var(--sand); }

      .sal-editorial-card { border-top: 1px solid var(--espresso); padding-top: 16px; width: 260px; }
      .sal-editorial-thumb { width: 100%; aspect-ratio: 4/3; border-radius: 2px; overflow: hidden; margin-bottom: 14px; background: var(--ink-soft); }
      .sal-editorial-cat { font-size: 11px; letter-spacing: 0.05em; text-transform: uppercase; color: var(--gold); margin: 0 0 10px; }
      .sal-editorial-title { font-size: 19px; margin: 0; }

      .sal-inline-link { font-size: 13px; color: var(--ink); text-decoration: none; border-bottom: 1px solid var(--gold); padding-bottom: 2px; transition: color 0.25s ease, border-color 0.25s ease; }
      .sal-inline-link:hover { color: var(--sienna); border-color: var(--sienna); }
      .sal-section-dark .sal-inline-link, .sal-section-sienna .sal-inline-link { color: var(--porcelain); border-color: var(--gold-soft); }
      .sal-section-dark .sal-inline-link:hover, .sal-section-sienna .sal-inline-link:hover { color: var(--gold-soft); border-color: var(--porcelain); }

      .sal-tag {
        display: inline-block; font-size: 10.5px; letter-spacing: 0.05em; text-transform: uppercase;
        padding: 4px 10px; border-radius: 999px; margin-top: 4px;
      }
      .sal-tag-soon { background: var(--sienna); color: var(--porcelain); }
      .sal-coming-soon { animation: sal-fade-simple 0.5s ease both; }
      .sal-coming-soon-title { font-size: 32px; margin: 0 0 12px; }
      @keyframes sal-fade-simple { from { opacity: 0; transform: translateY(6px); } to { opacity: 1; transform: translateY(0); } }

      .sal-case-dl { margin-top: 20px; max-width: 480px; }

      /* Hours */
      .sal-hours { max-width: 420px; border-top: 1px solid rgba(58,46,36,0.15); }
      .sal-section-dark .sal-hours, .sal-section-sienna .sal-hours { border-top-color: rgba(247,242,234,0.15); }
      .sal-hours-row {
        display: flex; align-items: baseline; justify-content: space-between;
        padding: 14px 0; border-bottom: 1px solid rgba(58,46,36,0.15);
      }
      .sal-section-dark .sal-hours-row, .sal-section-sienna .sal-hours-row { border-bottom-color: rgba(247,242,234,0.15); }
      .sal-hours-day { font-family: 'Fraunces', serif; font-size: 16px; text-transform: uppercase; letter-spacing: 0.03em; }
      .sal-hours-time { font-size: 13px; color: var(--espresso); }
      .sal-section-dark .sal-hours-time, .sal-section-sienna .sal-hours-time { color: var(--sand); }

      /* Legal pages */
      .sal-legal-block { max-width: 620px; margin-bottom: 32px; }
      .sal-legal-heading { font-size: 19px; margin: 0 0 8px; }

      .sal-case-dl dt { font-size: 11px; letter-spacing: 0.05em; text-transform: uppercase; color: var(--gold-soft); margin-top: 14px; }
      .sal-case-dl dd { margin: 4px 0 0; font-size: 14.5px; color: var(--sand); }
      .sal-disclaimer { margin-top: 20px; font-size: 12px; color: var(--sand); opacity: 0.7; max-width: 480px; }

      /* Journey modal */
      .sal-modal-overlay {
        position: fixed; inset: 0; z-index: 80; background: rgba(24,20,15,0.9);
        display: flex; align-items: center; justify-content: center; padding: 20px;
      }
      .sal-modal {
        background: var(--porcelain); color: var(--ink); max-width: 520px; width: 100%;
        border-radius: 6px; padding: 44px clamp(24px, 5vw, 48px); position: relative;
      }
      .sal-modal-close { position: absolute; top: 14px; right: 18px; color: var(--ink); }
      .sal-modal-step { font-size: 11px; letter-spacing: 0.08em; text-transform: uppercase; color: var(--sienna); margin: 0 0 10px; }
      .sal-modal-title { font-size: clamp(26px, 4vw, 34px); margin: 0 0 24px; }
      .sal-modal-context { font-size: 13px; color: var(--sienna); margin: 0 0 14px; }
      .sal-modal-options { display: flex; flex-wrap: wrap; gap: 10px; }
      .sal-modal-support { font-size: 14.5px; color: var(--espresso); line-height: 1.6; margin-bottom: 24px; }
      .sal-modal-cta { display: inline-block; }
      .sal-modal-back { margin-top: 18px; background: none; border: none; font-size: 12.5px; color: var(--espresso); text-decoration: underline; cursor: pointer; }

      /* ===== Second pass additions (new components only) ===== */

      /* Journey modal — guidance tone (modal-scoped) */
      .sal-modal .sal-modal-step { font-size: 13px; letter-spacing: 0.01em; text-transform: none; }
      .sal-modal-note { font-size: 12px; line-height: 1.55; color: var(--espresso); opacity: 0.7; margin: 22px 0 0; max-width: 400px; }
      .sal-modal .sal-cta-primary { background: var(--ink); color: var(--porcelain); }
      .sal-modal .sal-cta-primary:hover { background: var(--sienna); }

      /* "Antes de decidir" — treatment guide (full page) */
      .sal-guide { margin: 0; max-width: 760px; border-top: 1px solid rgba(58,46,36,0.18); }
      .sal-guide-row { display: grid; grid-template-columns: 1fr; gap: 6px; padding: var(--space-5) 0; border-bottom: 1px solid rgba(58,46,36,0.18); }
      @media (min-width: 780px) { .sal-guide-row { grid-template-columns: 240px 1fr; gap: var(--space-6); } }
      .sal-guide-label { font-size: 18px; margin: 0; }
      .sal-guide-text { font-size: 15px; line-height: 1.65; color: var(--espresso); margin: 0; max-width: 460px; }
      .sal-guide-text.is-pending, .sal-guide-pending { font-style: italic; opacity: 0.72; }
      .sal-public-claim { font-size: 12.5px; color: var(--espresso); opacity: 0.75; margin: var(--space-5) 0 0; max-width: 460px; }

      /* "Antes de decidir" — compact preview inside the explorer */
      .sal-guide-compact { margin: 0 0 4px; max-width: 400px; }
      .sal-guide-compact-title { font-size: 12px; letter-spacing: 0.02em; color: var(--ink); font-weight: 600; margin: 0 0 var(--space-2); }
      .sal-guide-compact-row { padding: var(--space-3) 0; border-top: 1px solid rgba(58,46,36,0.18); }
      .sal-guide-compact-label { font-family: 'Fraunces', serif; font-size: 15px; margin: 0 0 3px; }
      .sal-guide-compact-text { font-size: 13.5px; line-height: 1.55; color: var(--espresso); margin: 0; }
      .sal-guide-pending { font-size: 12.5px; line-height: 1.55; color: var(--espresso); margin: var(--space-2) 0 0; }

      /* Case structure — result told with context */
      .sal-case { max-width: 980px; }
      .sal-case-flag { font-size: 12px; letter-spacing: 0.04em; color: var(--gold-soft); margin: 0 0 var(--space-4); }
      .sal-case-frames { display: grid; grid-template-columns: 1fr 1fr; gap: var(--space-3); max-width: 560px; margin-bottom: var(--space-7); }
      .sal-case-frame { aspect-ratio: 4/5; border: 1px dashed rgba(217,189,142,0.35); background: rgba(247,242,234,0.03); display: flex; align-items: flex-end; padding: var(--space-4); }
      .sal-case-frame span { font-style: italic; font-size: 22px; color: var(--sand); opacity: 0.8; }
      .sal-case-flow { list-style: none; margin: 0 0 var(--space-6); padding: 0; position: relative; display: grid; grid-template-columns: 1fr; }
      .sal-case-step { position: relative; padding: 0 0 var(--space-5) var(--space-6); border-left: 1px solid rgba(247,242,234,0.16); }
      .sal-case-step:last-child { padding-bottom: 0; border-left-color: transparent; }
      .sal-case-step::before { content: ""; position: absolute; left: -4px; top: 6px; width: 7px; height: 7px; border-radius: 50%; background: var(--gold); opacity: 0; transition: opacity 0.5s ease; }
      .sal-case-step-label { font-size: 19px; margin: 0 0 4px; color: var(--porcelain); }
      .sal-case-step-text { font-size: 14px; line-height: 1.6; color: var(--sand); margin: 0; max-width: 300px; }
      .sal-case.is-in .sal-case-step::before { opacity: 1; }
      .sal-case.is-in .sal-case-step:nth-child(2)::before { transition-delay: 0.15s; }
      .sal-case.is-in .sal-case-step:nth-child(3)::before { transition-delay: 0.3s; }
      .sal-case.is-in .sal-case-step:nth-child(4)::before { transition-delay: 0.45s; }
      .sal-case.is-in .sal-case-step:nth-child(5)::before { transition-delay: 0.6s; }
      @media (min-width: 860px) {
        .sal-case-flow { grid-template-columns: repeat(5, 1fr); gap: var(--space-5); }
        .sal-case-flow::before { content: ""; position: absolute; left: 0; right: 0; top: 9px; height: 1px; background: rgba(247,242,234,0.16); transform: scaleX(0); transform-origin: left; transition: transform 1.2s cubic-bezier(0.16,1,0.3,1); }
        .sal-case.is-in .sal-case-flow::before { transform: scaleX(1); }
        .sal-case-step { padding: var(--space-6) 0 0; border-left: none; }
        .sal-case-step::before { left: 0; top: 6px; }
      }
      @media (prefers-reduced-motion: reduce) {
        .sal-case-flow::before { transform: scaleX(1) !important; transition: none !important; }
        .sal-case-step::before { opacity: 1 !important; transition: none !important; }
      }

      /* Agora preview note + My Salomão concept caption */
      .sal-agora-note { font-size: 12.5px; color: var(--sand); opacity: 0.8; margin: var(--space-5) 0 0; }
      .sal-phone-mock-caption { font-size: 10.5px; color: var(--sand); opacity: 0.55; margin: var(--space-4) 0 0; text-align: center; }

      /* Footer */
      .sal-footer { background: var(--ink); color: var(--sand); padding: var(--space-9) var(--container-padding) var(--space-6); }
      .sal-footer-top { display: flex; align-items: baseline; justify-content: space-between; flex-wrap: wrap; gap: var(--space-4); margin-bottom: var(--space-9); }
      .sal-footer-statement { font-family: 'Fraunces', serif; font-style: italic; font-size: 15px; color: var(--sand); opacity: 0.8; margin: 0; }
      .sal-footer-grid {
        display: grid; grid-template-columns: 1fr; gap: 40px;
        padding-bottom: 40px; border-bottom: 1px solid var(--ink-soft);
        max-width: 680px;
      }
      @media (min-width: 780px) { .sal-footer-grid { grid-template-columns: 1.4fr 1fr 1fr; } }
      .sal-footer-label { font-size: 11px; letter-spacing: 0.06em; text-transform: uppercase; color: var(--gold-soft); margin-bottom: 10px; }
      .sal-footer-grid a { display: block; font-size: 13px; color: var(--sand); text-decoration: none; margin-bottom: 8px; }
      .sal-footer-grid a:hover { color: var(--porcelain); }

      .sal-address-link {
        display: inline-block; text-decoration: none; cursor: pointer;
        border-bottom: 1px solid transparent; transition: border-color 0.25s ease, opacity 0.25s ease, transform 0.15s ease;
      }
      .sal-address-link:hover { border-color: var(--gold); opacity: 0.85; }
      .sal-address-link:active { transform: scale(0.99); }
      .sal-footer-legal-row {
        display: flex; flex-wrap: wrap; align-items: center; justify-content: space-between;
        gap: 12px; margin-top: 24px;
      }
      .sal-footer-legal { font-size: 11px; color: rgba(222,208,190,0.5); margin: 0; }
      .sal-footer-legal-links { display: flex; gap: 20px; }
      .sal-footer-legal-links a { font-size: 11px; color: rgba(222,208,190,0.6); text-decoration: underline; margin: 0; }
      .sal-footer-legal-links a:hover { color: var(--porcelain); }

      @media (prefers-reduced-motion: reduce) {
        .sal-headline .line span, .sal-page-transition { transition: none !important; animation: none !important; transform: none !important; opacity: 1 !important; clip-path: inset(0 0 0% 0) !important; }
      }
    `}</style>
  );
}
