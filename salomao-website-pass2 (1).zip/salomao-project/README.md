# Salomão Website — Prototype

A single-page React app (hash-routed, no backend) built as a design/UX prototype for
Clínica de Estética Salomão. Not yet connected to any CMS or booking system —
conversion happens entirely through WhatsApp deep links.

## Run locally

```bash
npm install
npm run dev
```

Build for deployment (Vercel / Netlify — just point either at this repo, framework
preset "Vite"):

```bash
npm run build
```

## What's real vs. placeholder

- **Contact info** (`CONTACT` object in `src/SalomaoSite.jsx`): address, phone, and
  WhatsApp number are centralized in one place. The suite number (Cj. 309) reflects
  the Instagram bio as of this build — an earlier source (the official website)
  listed Cj. 306. **This conflict has not been resolved by the clinic and needs
  confirmation before launch.**
- **Services**: the six treatment categories are real, pulled from the official site.
  Most of their descriptions are generic/public knowledge, not clinic-specific copy —
  marked for follow-up in the data itself.
- **Team**: three real names (Ana Paula Dantas, Isana Azevedo, Márcia Romão) appear
  publicly in the clinic's own Instagram content. Formal titles/credentials were
  deliberately left out since they weren't independently verified.
- **Results, team photos, and most editorial articles are placeholder content.**
  Photography is real (free-license Pexels/Unsplash, listed below) but is
  **not** Salomão's own photography — it's temporary editorial imagery, captioned
  as such in the UI, meant to be swapped for real clinic assets before launch.
- **My Salomão** is intentionally not built out as a real app — this project is the
  public website only, per an explicit scope lock. The page shows an "em breve" state.

## Photography & video credits (temporary assets)

**Video** — real footage supplied directly by the client, used as cinematic
background media:
- `public/videos/hero.mp4` — home hero background (re-encoded from the original
  1920×1080 upload to ~1.2MB for web delivery)
- `public/videos/belief-skincare.mp4` — "A estética começa antes do espelho"
  section background (re-encoded from a 4K/33MB original down to ~2.9MB, audio
  stripped since it's a muted background video)
- Poster fallbacks (`hero-poster.jpg`, `belief-poster.jpg`) are shown instead of
  the video when the visitor has `prefers-reduced-motion` enabled.

**Photography** — free-license stock (Pexels License / Unsplash License, both
free for commercial use, no attribution required), used as temporary editorial
imagery everywhere else:

- Treatments series: Anna Shvets, via Pexels (photos 4586713, 4586712, 4586724,
  4586723, 4586714, 4586721)
- Results / Method / Edit stills: various Pexels contributors (photos 30979444,
  15569182, 29176565, 2566853, 7815016)

Replace the `MEDIA` object and the `public/videos/` files in `src/SalomaoSite.jsx`
with real clinic assets when available.

## Known gaps

- Spacing token system (`--space-1` through `--space-12`, plus `--container-padding`)
  added to the root and applied to the major structural rules — section padding,
  page-hero padding, footer padding, section titles, eyebrow labels. Not every
  single spacing value in the file was migrated to a token; this is a real start
  on the system, not a full site-wide token-ization.
- Hero video brightness is now scroll-controlled correctly: the video itself
  never dims, only a separate dark scrim layered on top does (starts ~0.38
  opacity, eases to ~0.12 as the hero scrolls away). The previous version had
  this backwards.
- Footer no longer repeats the Contact page's WhatsApp/phone/email/hours/address
  — those live on `/contato` only now. "Contato" remains in the mobile menu and
  is reachable there, same as before.
- **Not implemented**: the broader "joy / discovery / digital-house" experience
  direction (referenced against an uploaded Rhode Skin recording) was
  acknowledged but not built out this round — that's a substantially larger
  interaction-design project (progressive reveal mechanics, a livelier Edit,
  more playful micro-interactions throughout) than could responsibly be done
  as an add-on to the concrete spacing/footer/hero fixes in the same pass.
  Flagging honestly rather than claiming partial cosmetic tweaks satisfy it.

- No real Google Business / Reclame Aqui data — those sections were never located
  during research.
- No CNPJ registry confirmation.
- Accessibility, SEO metadata, and performance were addressed partially, not
  audited end-to-end.
- Routing is a hand-rolled hash router (no `react-router-dom`) — swap in a real
  router if this moves toward production. It now supports back-navigation with
  scroll-position memory (`goBack()` in the router context, used by the
  "← Voltar" link on every inner page), but this is an in-memory approximation,
  not wired into the real History API state — it won't survive a hard reload.
- **No admin/CMS UI exists.** The Edit's content model (`EDITORIAL` array) has
  the fields a real admin panel would need — `type`, `status`, `featured`,
  `date`, `author` — and only `status: "published"` items are ever shown
  publicly. But there is no dashboard, no auth, and no way to actually publish
  new content short of editing this file. That's deliberate: a fake admin UI
  would be worse than none. Swapping this array for a real API/Supabase call
  is the only change a real integration would need.
- Legal pages (`/privacidade`, `/termos`) have placeholder body text, clearly
  marked as such in the data layer (`LEGAL_PLACEHOLDER`) — not invented legal
  wording. Needs the clinic's actual approved text.
- Legal footer links are always visible since there's no cookie-consent banner
  in this build to gate them behind.
- A "Salomão Agora" strip was added to the homepage (between The Edit and My
  Salomão) surfacing real published content — no invented announcements, no
  fake urgency/countdowns. If nothing is published it simply doesn't render.
- The Discovery flow's first step now gives a brief visible "selected" state
  (fill + scale) before advancing, instead of an instant cut to the next
  question — a small, honest step toward the "this is me" feeling asked for,
  not a full gamified redesign of the interaction.
- **Not attempted this round**: full home-page re-choreography into "rooms,"
  Method-section scroll-triggered line growth, a full CTA-hierarchy audit, or
  a systematic section-rhythm pass. Most of the other concrete asks in this
  round's brief (hero overlay behavior, footer/nav structure, spacing tokens,
  back navigation, contact/legal centralization, the Edit content model,
  treatment mobile accordion) were already built in earlier rounds and did not
  need to be redone.

### Follow-up pass: the four items above, given dedicated attention

- **Method line growth** — the connecting line on `/metodo` now actually grows
  as you scroll through the four stages (`MethodSequence` component), driven
  by IntersectionObserver, forward-only (doesn't retract scrolling back up).
  Fixed a real bug in my own first draft: percentage `height` doesn't resolve
  on an absolutely-positioned element inside an auto-height container, so the
  fill is measured and animated in real pixels instead.
- **CTA hierarchy audit** — went through every button/link in the file.
  Found and fixed two real issues: a dead inline style duplicating a class's
  own default, and one "Fale com a equipe" (explicitly secondary-tier) styled
  with primary-button weight on the Clínica page. Added missing hover/active
  states to the header's compact CTA. The rest (~16 contextual links, ~12
  secondary buttons) was already consistent.
- **Section-rhythm audit** — found a real problem my own earlier spacing-token
  pass had introduced: every `.sal-section` had been flattened to identical
  padding, which directly contradicts "not every section the same height."
  Added `size="quiet"` / `size="major"` variants and applied them deliberately
  (intro and closing sections are now shorter; The Edit gets more room). Also
  found three consecutive high-interaction sections back to back (Discovery →
  Treatments → Results) with no breathing room between them, and inserted a
  genuinely quiet pause — using real, already-verified clinic language ("Sem
  promessas. Só resultados.") rather than inventing new copy.
- **Room transitions** — found the most glaring gap: the Belief video section
  had zero scroll-reveal treatment, unlike literally every other section on
  the page, so it just appeared with a hard cut. Gave it a real clip-path
  mask entrance (edges pull back as it scrolls into view — a "door opening"
  feel) matching the reveal treatment everything else already had. This is a
  genuine fix, but it is not a full re-choreography of every section boundary
  into a unique transition device — that's a larger undertaking than one pass
  over an already very large file can responsibly claim to have finished.

### Latest pass: cross-linking, header CTA removal, scroll-behavior fix

- **"Web of discovery" cross-linking** — treatments, editorial content, and
  team profiles now link to each other where a genuine, research-backed
  connection exists (e.g. the "Fios de Sustentação" treatment links to the
  real "Arquitetura da Beleza" course and its related article; Ana Paula
  Dantas's profile links back to both). These are curated by hand, not
  auto-matched by fuzzy string logic — only 6 treatments and 4 editorial
  items exist, so a few honest, deliberate connections are more trustworthy
  than a matching algorithm guessing at relationships. Rendered as soft
  `sal-inline-link`-style links, not another primary CTA — they invite
  further reading, they don't push toward WhatsApp.
- **Removed the persistent header "Começar sua jornada" button** (it used to
  show at ≥1180px next to My Salomão) — an explicit instruction to reduce
  constant conversion pressure. The CTA still exists contextually throughout
  the site (hero, treatment pages, footer's discovery moment, mobile drawer).
- **Fixed a real bug**, not just a style preference: the scroll-restoration
  code used `"instant" in window ? "instant" : "auto"` as if it were
  feature-detecting browser support for `scrollTo({ behavior: "instant" })`.
  It wasn't — `"instant" in window` checks for a property literally named
  `instant` on the `window` object, which never exists, so the condition was
  always `false` and the code was silently already falling back to `"auto"`.
  Simplified to just `behavior: "auto"` directly — same runtime behavior,
  honest code.
- Verified the footer already matches this round's requested structure
  (SALOMÃO → Navegação → Salomão [My Salomão, Contato] → Acompanhe → legal)
  from a prior correction — no changes needed there.

### Honest limitations of this pass

- No `npm install` / build was run — this sandbox has no network access to
  fetch packages. The code was verified by parsing (brace/paren balance,
  route/function counts, dead-code sweeps) after every batch of edits, not by
  an actual compile or browser render. Please run `npm run build` before
  deploying.
- Visual/responsive QA at specific breakpoints (375/390/430px, tablet,
  desktop) was not performed — there's no way to render and screenshot this
  project in this environment. The CSS is responsive by construction (clamp(),
  media queries, mobile-specific components like the treatment accordion),
  but it hasn't been visually confirmed at each width.
- Keyboard/focus/Escape behavior was implemented deliberately (journey modal
  focus trap, mobile drawer Escape-to-close, visible focus states) but not
  tested with an actual screen reader or keyboard-only pass.

### Real QA pass (supersedes the limitations above)

This environment turned out to have Node, esbuild, and Playwright (with a
Chromium binary) already installed globally. Used them instead of just
inspecting source:

- **Build**: bundled the real app with esbuild (`--bundle --jsx=automatic`).
  Compiled cleanly — a genuine syntax/reference validation, not a guess.
  `npm run build` with Vite itself still hasn't been run (no network to
  install Vite), but the JSX/JS is confirmed valid by a real toolchain.
- **Runtime**: launched real Chromium via Playwright, served the bundle over
  local HTTP, loaded all 15 real routes plus one invalid route. All 15
  rendered real content; the invalid route correctly showed the 404 page.
  Zero console/page errors except Google Fonts requests failing (expected —
  no outbound network in this sandbox; works fine in real deployment).
- **Responsive**: screenshotted Home, Tratamentos, and Contato at
  375/390/430/768/1024/1440px (18 combinations) and measured `scrollWidth`
  vs `clientWidth` — zero horizontal overflow anywhere. **Found and fixed a
  real bug this way**: the floating "Fale com a Salomão" contact pill
  overlapped and, at 375px, literally clipped the text of the hero's primary
  CTA button. Fixed by collapsing the pill to an icon-only circle below
  480px width, then re-screenshotted to confirm — button text is now fully
  visible with no overlap.
- **Keyboard**: tabbed through the header for real — logo → 6 nav items →
  My Salomão → menu button → contact pill, each receiving a visible focus
  outline. Opened the mobile drawer and closed it with a real Escape
  keypress. Opened the journey modal, confirmed focus lands on the close
  button, closed with Escape, reopened, clicked a goal option, confirmed it
  advances to step 2.
- **One false alarm worth documenting honestly**: an early test used an
  unscoped `.sal-option` selector and appeared to show modal buttons
  positioned thousands of pixels off-screen after a reopen. Investigated
  rather than assuming either "it's broken" or "it's fine" — the real cause
  was that the Home page's own "Descubra" section uses the same class, so
  the unscoped selector grabbed that element instead. Scoped to `.sal-modal`,
  the interaction works correctly.
- **WhatsApp links**: verified an actual generated href from a treatment
  page — correctly encoded, correct treatment name in the message.
- **Hero video**: confirmed the `<video>` element has the right `src` and
  `muted`/`loop`/`autoplay`/`playsInline` attributes, and that the
  scroll-linked brightness scrim's opacity genuinely changes with scroll
  (measured 0.38 at top, 0.163 at scrollY=500 — matches the coded formula
  exactly). **The video would not decode in this test browser** — Chromium
  reported `DEMUXER_ERROR_NO_SUPPORTED_STREAMS`. Diagnosed rather than
  assumed: `ffprobe` confirms the file is standard H.264 (High profile,
  yuv420p), a universally-supported web format, and this sandbox only has
  the open-source Chromium build (no licensed Google Chrome channel), which
  is well known not to include H.264 decoding. Real Chrome, Safari, Firefox,
  and Edge all support this format. Flagged as unverified-in-this-sandbox,
  not assumed-fine.

## Structure

```
src/
  SalomaoSite.jsx   — the entire app: data, routing, components, styles
  main.jsx          — Vite/React entry point
index.html
```

Everything lives in one file by design (this began as a single-file prototype);
splitting it into components/pages is a reasonable next step before production.
